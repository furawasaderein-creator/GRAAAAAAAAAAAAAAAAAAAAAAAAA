from __future__ import annotations

import json
import logging
import math
import base64
import binascii
import os
import secrets
import sqlite3
import ssl
import tempfile
import threading
import time
from datetime import datetime
from contextlib import closing
from datetime import date, datetime
from http.cookies import SimpleCookie
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlsplit

from config import MINIMUM_EMPLOYEE_AGE
from database.database import (
    DatabaseManager,
    REQUEST_TYPES,
    hash_password,
    password_needs_rehash,
    verify_password,
)
from payroll_app.calculations import (
    calculate_attendance_hours,
    calculate_hourly_gross,
    calculate_late_minutes,
    calculate_paid_leave_hours,
    calculate_philippine_deductions,
    is_full_calendar_month,
)
from payroll_app.dsa import ChainedHashMap, linear_search_records, merge_sort_records

BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIST = BASE_DIR / "frontend" / "dist"
SESSION_COOKIE = "payroll_session"
SESSION_SECONDS = 8 * 60 * 60
MAX_REQUEST_BYTES = 32 * 1024 * 1024
MAX_PROFILE_IMAGE_BYTES = 5 * 1024 * 1024
MAX_PASSWORD_LENGTH = 1024
logger = logging.getLogger("payroll.web")
db_manager = DatabaseManager()
sessions: dict[str, tuple[dict[str, Any], float]] = {}
sessions_lock = threading.Lock()


def _month_range(year: int, month: int) -> tuple[str, str]:
    start = date(year, month, 1)
    if month == 12:
        end = date(year + 1, 1, 1)
    else:
        end = date(year, month + 1, 1)
    return start.isoformat(), end.isoformat()


def _profile_image_mime(image_data: bytes) -> str | None:
    if image_data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if image_data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if image_data.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    if len(image_data) >= 12 and image_data[:4] == b"RIFF" and image_data[8:12] == b"WEBP":
        return "image/webp"
    return None


def _payslip_for_request(
    connection: sqlite3.Connection, employee_id: int, details: dict[str, Any]
) -> dict[str, Any] | None:
    payslip = connection.execute(
        "SELECT p.period_start, p.period_end, p.gross_pay, p.sss_deduction, "
        "p.philhealth_deduction, p.pagibig_deduction, p.tax_withheld, "
        "p.other_deductions, p.tardiness_deduction, p.net_pay, "
        "e.first_name || ' ' || e.last_name AS employee "
        "FROM payroll p JOIN employees e ON e.employee_id=p.employee_id "
        "WHERE p.employee_id=? AND p.period_start=? AND p.period_end=?",
        (employee_id, details["period_start"], details["period_end"]),
    ).fetchone()
    return dict(payslip) if payslip else None


class PayrollRequestHandler(SimpleHTTPRequestHandler):
    server_version = "PayrollWeb/1.0"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, directory=str(FRONTEND_DIST), **kwargs)

    def send_response(self, code: int, message: str | None = None) -> None:
        self._response_status = code
        super().send_response(code, message)

    def end_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        super().end_headers()

    def do_GET(self) -> None:
        path = urlsplit(self.path).path
        if path.startswith("/api/"):
            self._handle_api_get(path)
            return
        if not FRONTEND_DIST.is_dir():
            self.send_error(
                503,
                "React app not built. Run `npm install` and `npm run build` in the frontend folder.",
            )
            return
        requested_file = Path(self.translate_path(path))
        if not requested_file.is_file():
            self.path = "/index.html"
        super().do_GET()

    def do_POST(self) -> None:
        path = urlsplit(self.path).path
        if not path.startswith("/api/"):
            self.send_error(404)
            return
        try:
            self._validate_request_origin()
            body = self._read_json()
            if path == "/api/login":
                self._login(body)
            elif path == "/api/password-reset-requests":
                self._submit_password_reset_request(body)
            elif path == "/api/logout":
                self._logout()
            elif path.startswith("/api/"):
                self._handle_api_action(path.removeprefix("/api/"), body)
            else:
                self._send_json(404, {"error": "Endpoint not found."})
        except ValueError as exc:
            self._send_json(400, {"error": str(exc)})
        except PermissionError as exc:
            self._send_json(403, {"error": str(exc)})
        except sqlite3.IntegrityError as exc:
            self._send_json(409, {"error": self._integrity_message(exc)})
        except sqlite3.Error:
            logger.exception("Payroll database request failed")
            self._send_json(500, {"error": "The payroll database request failed."})
        except OSError as exc:
            logger.exception("Payroll file operation failed")
            self._send_json(500, {"error": "Could not complete the requested file operation."})

    def _handle_api_get(self, path: str) -> None:
        try:
            if path == "/api/backup":
                user = self._current_user()
                if user is None:
                    self._send_json(401, {"error": "Please sign in to continue."})
                elif user.get("mustChangePassword"):
                    self._send_json(403, {"error": "Change your temporary password to continue."})
                else:
                    self._download_backup(user)
                return
            if path == "/api/session":
                user = self._current_user()
                if user is not None:
                    user = self._profile_user(user)
                self._send_json(200, {"user": user})
                return

            user = self._current_user()
            if user is None:
                self._send_json(401, {"error": "Please sign in to continue."})
            elif user.get("mustChangePassword"):
                self._send_json(403, {"error": "Change your temporary password to continue."})
            elif path == "/api/dashboard":
                self._send_json(200, self._dashboard_data(user))
            elif path.startswith("/api/employees/") and path.endswith("/profile-image"):
                employee_id = path.removeprefix("/api/employees/").removesuffix("/profile-image").strip("/")
                if not employee_id.isdecimal():
                    self._send_json(404, {"error": "Employee profile photo not found."})
                else:
                    self._send_employee_profile_image(user, int(employee_id))
            elif path.startswith("/api/"):
                employee_query = ""
                employee_sort = "name"
                if path == "/api/employees":
                    query = parse_qs(urlsplit(self.path).query, keep_blank_values=True)
                    employee_query = query.get("query", [""])[0]
                    employee_sort = query.get("sort", ["name"])[0]
                payload = self._get_section(
                    path.removeprefix("/api/"),
                    user,
                    employee_query=employee_query,
                    employee_sort=employee_sort,
                )
                self._send_json(200, payload)
            else:
                self._send_json(404, {"error": "Endpoint not found."})
        except PermissionError as exc:
            self._send_json(403, {"error": str(exc)})
        except ValueError as exc:
            self._send_json(400, {"error": str(exc)})
        except sqlite3.Error:
            logger.exception("Payroll database request failed")
            self._send_json(500, {"error": "The payroll database request failed."})
        except OSError as exc:
            logger.exception("Payroll file operation failed")
            self._send_json(500, {"error": "Could not complete the requested file operation."})

    @staticmethod
    def _integrity_message(error: sqlite3.IntegrityError) -> str:
        message = str(error).lower()
        if "unique" in message:
            return "A record with the same unique value already exists."
        if "foreign key" in message:
            return "The selected related record does not exist or is still in use."
        if "check constraint" in message:
            return "One or more values are not allowed."
        return "The record conflicts with existing payroll data."

    @staticmethod
    def _require_role(user: dict[str, Any], roles: tuple[str, ...], action: str) -> None:
        if user["role"] not in roles:
            raise PermissionError(f"Your account does not have permission to {action}.")

    @staticmethod
    def _date(value: Any, label: str) -> str:
        if not isinstance(value, str):
            raise ValueError(f"Enter a valid {label}.")
        try:
            return date.fromisoformat(value.strip()).isoformat()
        except ValueError as exc:
            raise ValueError(f"Enter a valid {label}.") from exc

    @staticmethod
    def _number(value: Any, label: str, *, minimum: float = 0) -> float:
        try:
            result = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Enter a valid {label}.") from exc
        if not math.isfinite(result) or result < minimum:
            raise ValueError(f"{label} must be a finite number of at least {minimum:g}.")
        return result

    def _get_section(
        self,
        section: str,
        user: dict[str, Any],
        *,
        employee_query: str = "",
        employee_sort: str = "name",
    ) -> dict[str, Any]:
        if section == "employees":
            self._require_role(user, ("admin", "hr"), "access the employee directory")
            return {"employees": self._employees(employee_query, employee_sort)}
        if section == "departments":
            self._require_role(user, ("admin", "hr"), "view departments")
            with closing(db_manager.connect()) as connection:
                departments = connection.execute(
                    "SELECT d.department_id, d.department_name, "
                    "(SELECT COUNT(*) FROM employees e WHERE e.department_id=d.department_id) AS employee_count "
                    "FROM departments d ORDER BY d.department_name COLLATE NOCASE"
                ).fetchall()
                positions = connection.execute(
                    "SELECT position_id, department_id, position_name FROM department_positions "
                    "ORDER BY position_name COLLATE NOCASE"
                ).fetchall()
            return {
                "departments": [dict(row) for row in departments],
                "positions": [dict(row) for row in positions],
            }
        if section == "attendance":
            self._require_role(user, ("admin", "hr", "accounting"), "view attendance")
            with closing(db_manager.connect()) as connection:
                rows = connection.execute(
                    "SELECT a.attendance_id AS id, a.employee_id, "
                    "e.employee_code, e.first_name || ' ' || e.last_name AS employee, "
                    "COALESCE(d.department_name, 'Unassigned') AS department, a.date, "
                    "a.time_in, a.time_out, a.hours_worked, a.overtime_hours, a.late_minutes "
                    "FROM attendance a JOIN employees e ON e.employee_id=a.employee_id "
                    "LEFT JOIN departments d ON d.department_id=e.department_id "
                    "ORDER BY a.date DESC, e.last_name, e.first_name"
                ).fetchall()
                employees = connection.execute(
                    "SELECT employee_id AS id, employee_code, first_name || ' ' || last_name AS name, "
                    "scheduled_start_time, scheduled_end_time FROM employees "
                    "WHERE status='active' ORDER BY last_name, first_name"
                ).fetchall()
                records = [dict(row) for row in rows]
            return {
                "records": records,
                "summary": {
                    "records": len(rows),
                    "hours": round(sum(float(row["hours_worked"] or 0) for row in rows), 2),
                    "overtime": round(sum(float(row["overtime_hours"] or 0) for row in rows), 2),
                    "lateMinutes": sum(int(row["late_minutes"] or 0) for row in rows),
                },
                "employees": [
                    dict(row)
                    for row in employees
                ],
            }
        if section == "leaves":
            self._require_role(user, ("admin", "hr"), "view leave records")
            with closing(db_manager.connect()) as connection:
                rows = connection.execute(
                    "SELECT l.leave_id AS id, l.employee_id, e.employee_code, "
                    "e.first_name || ' ' || e.last_name AS employee, "
                    "l.leave_type, l.start_date, l.end_date, l.status, l.notes, l.remarks, l.source_request_id "
                    "FROM leave_records l JOIN employees e ON e.employee_id=l.employee_id "
                    "ORDER BY l.start_date DESC, l.leave_id DESC"
                ).fetchall()
                employees = connection.execute(
                    "SELECT employee_id AS id, employee_code, first_name || ' ' || last_name AS name, gender "
                    "FROM employees WHERE status='active' ORDER BY last_name, first_name"
                ).fetchall()
            return {
                "records": [dict(row) for row in rows],
                "employees": [
                    dict(row)
                    for row in employees
                ],
            }
        if section == "documents":
            self._require_role(user, ("admin", "hr", "viewer", "accounting"), "view approved employee documents")
            with closing(db_manager.connect()) as connection:
                query = (
                    "SELECT r.request_id AS id, r.employee_id, e.employee_code, "
                    "e.first_name || ' ' || e.last_name AS employee, "
                    "COALESCE(d.department_name, 'Unassigned') AS department, "
                    "r.request_type, r.details, r.submitted_at, "
                    "reviewer.username AS reviewed_by "
                    "FROM employee_requests r "
                    "JOIN employees e ON e.employee_id=r.employee_id "
                    "LEFT JOIN departments d ON d.department_id=e.department_id "
                    "LEFT JOIN users reviewer ON reviewer.id=r.reviewed_by "
                    "WHERE r.status='Approved' "
                    "AND r.request_type IN ('Accomplishment Report','Clearance','Pass Slip',"
                    "'Certificate of Employment (COE)','Payslip') "
                )
                parameters: tuple[Any, ...] = ()
                if user["role"] == "viewer":
                    query += "AND r.employee_id=(SELECT employee_id FROM users WHERE id=?) "
                    parameters = (user["id"],)
                elif user["role"] == "hr":
                    query += "AND r.request_type!='Payslip' "
                elif user["role"] == "accounting":
                    query += "AND r.request_type='Payslip' "
                rows = connection.execute(
                    query + "ORDER BY r.submitted_at DESC, r.request_id DESC",
                    parameters,
                ).fetchall()
                records = [dict(row) for row in rows]
                for record in records:
                    if record["request_type"] == "Payslip":
                        record["payslip"] = _payslip_for_request(
                            connection,
                            int(record["employee_id"]),
                            json.loads(str(record["details"])),
                        )
                employees = []
                if user["role"] == "hr":
                    employees = connection.execute(
                        "SELECT employee_id AS id, employee_code, "
                        "first_name || ' ' || last_name AS name "
                        "FROM employees ORDER BY last_name COLLATE NOCASE, first_name COLLATE NOCASE"
                    ).fetchall()
            return {
                "records": records,
                "employees": [dict(row) for row in employees],
            }
        if section == "payroll":
            self._require_role(user, ("admin", "accounting"), "access payroll")
            with closing(db_manager.connect()) as connection:
                rows = connection.execute(
                    "SELECT p.payroll_id AS id, p.employee_id, e.employee_code, "
                    "e.first_name || ' ' || e.last_name AS employee, "
                    "p.period_start, p.period_end, p.gross_pay, p.deductions, p.sss_deduction, "
                    "p.philhealth_deduction, p.pagibig_deduction, p.tax_withheld, p.other_deductions, "
                    "p.paid_leave_hours, p.tardiness_minutes, p.tardiness_deduction, p.net_pay, p.generated_at "
                    "FROM payroll p JOIN employees e ON e.employee_id=p.employee_id "
                    "ORDER BY p.period_end DESC, p.generated_at DESC, p.payroll_id DESC"
                ).fetchall()
                deductions = connection.execute(
                    "SELECT d.employee_id, e.employee_code, e.first_name || ' ' || e.last_name AS employee, d.other "
                    "FROM deductions d JOIN employees e ON e.employee_id=d.employee_id "
                    "ORDER BY e.last_name, e.first_name"
                ).fetchall()
                employees = connection.execute(
                    "SELECT employee_id AS id, employee_code, first_name || ' ' || last_name AS name "
                    "FROM employees WHERE status='active' ORDER BY last_name, first_name"
                ).fetchall()
            return {
                "records": [dict(row) for row in rows],
                "deductions": [dict(row) for row in deductions],
                "employees": [
                    dict(row)
                    for row in employees
                ],
            }
        if section == "reports":
            self._require_role(user, ("admin", "accounting"), "access payroll reports")
            from urllib.parse import parse_qs
            query = parse_qs(urlsplit(self.path).query)
            today = date.today()
            start = self._date(query.get("start", [today.replace(day=1).isoformat()])[0], "start date")
            end = self._date(query.get("end", [today.isoformat()])[0], "end date")
            if end < start:
                raise ValueError("The report end date cannot be before its start date.")
            with closing(db_manager.connect()) as connection:
                rows = connection.execute(
                    "SELECT p.payroll_id AS id, e.employee_id, e.employee_code, "
                    "e.first_name || ' ' || e.last_name AS employee, "
                    "COALESCE(d.department_name, 'Unassigned') AS department, p.period_start, p.period_end, "
                    "p.gross_pay, p.deductions, p.sss_deduction, p.philhealth_deduction, "
                    "p.pagibig_deduction, p.tax_withheld, p.other_deductions, p.paid_leave_hours, "
                    "p.tardiness_minutes, p.tardiness_deduction, p.net_pay, p.generated_at "
                    "FROM payroll p JOIN employees e ON e.employee_id=p.employee_id "
                    "LEFT JOIN departments d ON d.department_id=e.department_id "
                    "WHERE p.period_start >= ? AND p.period_end <= ? "
                    "ORDER BY p.period_end DESC, e.last_name, e.first_name",
                    (start, end),
                ).fetchall()
            records = [dict(row) for row in rows]
            return {
                "start": start, "end": end, "records": records,
                "totals": {
                    "records": len(records),
                    "employees": len({int(row["employee_id"]) for row in records}),
                    "gross": round(sum(float(row["gross_pay"]) for row in records), 2),
                    "deductions": round(sum(float(row["deductions"]) + float(row["tardiness_deduction"]) for row in records), 2),
                    "net": round(sum(float(row["net_pay"]) for row in records), 2),
                },
            }
        if section == "requests":
            with closing(db_manager.connect()) as connection:
                query = (
                    "SELECT r.request_id AS id, r.employee_id, e.employee_code, "
                    "e.first_name || ' ' || e.last_name AS employee, "
                    "COALESCE(d.department_name, 'Unassigned') AS department, r.request_type, r.details, "
                    "r.status, r.submitted_at, r.review_note, l.status AS leave_status, l.leave_id "
                    "FROM employee_requests r "
                    "JOIN employees e ON e.employee_id=r.employee_id "
                    "LEFT JOIN departments d ON d.department_id=e.department_id "
                    "LEFT JOIN leave_records l ON l.source_request_id=r.request_id "
                    "WHERE NOT (r.status='Approved' AND r.request_type IN "
                    "('Accomplishment Report','Clearance','Pass Slip',"
                    "'Certificate of Employment (COE)','Payslip')) "
                )
                parameters: tuple[Any, ...] = ()
                if user["role"] == "viewer":
                    query += "AND r.employee_id=(SELECT employee_id FROM users WHERE id=?) "
                    parameters = (user["id"],)
                elif user["role"] == "hr":
                    query += "AND r.request_type NOT IN ('Leave','Travel Order','Payslip') "
                elif user["role"] == "accounting":
                    query += "AND r.request_type = 'Payslip' "
                elif user["role"] != "admin":
                    raise PermissionError("Your account does not have access to employee requests.")
                if user["role"] != "viewer":
                    query += "AND NOT (r.status='Approved' AND r.request_type IN ('Leave','Travel Order')) "
                rows = connection.execute(query + "ORDER BY r.submitted_at DESC, r.request_id DESC", parameters).fetchall()
                linked = connection.execute(
                    "SELECT employee_id FROM users WHERE id=?", (user["id"],)
                ).fetchone()
                profile = connection.execute(
                    "SELECT gender FROM employees WHERE employee_id=?",
                    (linked["employee_id"],),
                ).fetchone() if linked and linked["employee_id"] else None
                employees = []
                if user["role"] == "hr":
                    employees = connection.execute(
                        "SELECT employee_id AS id, employee_code, "
                        "first_name || ' ' || last_name AS name "
                        "FROM employees ORDER BY last_name COLLATE NOCASE, first_name COLLATE NOCASE"
                    ).fetchall()
                records = [dict(row) for row in rows]
            return {
                "records": records,
                "canSubmit": user["role"] == "viewer" and bool(linked and linked["employee_id"]),
                "reviewRole": user["role"],
                "employees": [dict(row) for row in employees],
                "gender": str(profile["gender"] or "").lower() if profile else "",
                "requestTypes": list(REQUEST_TYPES),
            }
        if section == "settings":
            with closing(db_manager.connect()) as connection:
                values = {
                    str(row["setting_key"]): str(row["setting_value"])
                    for row in connection.execute("SELECT setting_key, setting_value FROM app_settings")
                }
            values = {
                "organization_name": "LSPU PAYROLL SYSTEM",
                "organization_tagline": "Human Resource & Payroll Control Center",
                "currency_symbol": "₱",
                "appearance_mode": "light",
                "office_location": "",
                "hr_contact": "",
                "work_days": "Monday-Friday",
                "office_start_time": "09:00",
                "office_end_time": "17:00",
                "break_duration_minutes": "60",
                "company_policies": "",
                **values,
            }
            return {"settings": values, "canEdit": user["role"] == "admin"}
        if section == "accounts":
            self._require_role(user, ("admin",), "manage user accounts")
            with closing(db_manager.connect()) as connection:
                rows = connection.execute(
                    "SELECT u.id, u.username, u.role, u.employee_id, e.employee_code, "
                    "CASE WHEN u.employee_id IS NULL THEN '' ELSE e.first_name || ' ' || e.last_name END AS employee "
                    "FROM users u LEFT JOIN employees e ON e.employee_id=u.employee_id ORDER BY u.username"
                ).fetchall()
                employees = connection.execute(
                    "SELECT e.employee_id AS id, e.employee_code, e.first_name || ' ' || e.last_name AS name "
                    "FROM employees e WHERE e.status='active' ORDER BY e.last_name, e.first_name"
                ).fetchall()
                reset_requests = connection.execute(
                    "SELECT r.id, u.username, r.submitted_at FROM password_reset_requests r "
                    "JOIN users u ON u.id = r.user_id WHERE r.status = 'Pending' "
                    "ORDER BY r.submitted_at, r.id"
                ).fetchall()
            return {
                "accounts": [dict(row) for row in rows],
                "employees": [dict(row) for row in employees],
                "passwordResetRequests": [dict(row) for row in reset_requests],
            }
        raise ValueError("Unknown payroll section.")

    def _handle_api_action(self, section: str, body: dict[str, Any]) -> None:
        user = self._current_user()
        if user is None:
            self._send_json(401, {"error": "Please sign in to continue."})
            return
        if user.get("mustChangePassword") and not (
            section == "accounts" and body.get("action") == "change-password"
        ):
            self._send_json(403, {"error": "Change your temporary password to continue."})
            return
        result: dict[str, Any]
        if section == "employees":
            result = self._employee_action(user, body)
        elif section == "departments":
            result = self._department_action(user, body)
        elif section == "attendance":
            result = self._attendance_action(user, body)
        elif section == "leaves":
            result = self._leave_action(user, body)
        elif section == "payroll":
            result = self._payroll_action(user, body)
        elif section == "requests":
            result = self._request_action(user, body)
        elif section == "settings":
            result = self._settings_action(user, body)
        elif section == "accounts":
            result = self._account_action(user, body)
        elif section == "profile":
            result = self._profile_action(user, body)
        else:
            self._send_json(404, {"error": "Endpoint not found."})
            return
        self._send_json(200, result)

    def _employee_action(self, user: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
        self._require_role(user, ("admin", "hr"), "edit employee records")
        action = body.get("action")
        employee_id = body.get("id")
        with closing(db_manager.connect()) as connection:
            with connection:
                if action == "delete":
                    if not employee_id:
                        raise ValueError("Choose an employee to delete.")
                    exists = connection.execute(
                        "SELECT 1 FROM employees WHERE employee_id=?", (employee_id,)
                    ).fetchone()
                    if not exists:
                        raise ValueError("Employee not found.")
                    connection.execute("DELETE FROM employees WHERE employee_id=?", (employee_id,))
                    return {"ok": True}
                if action == "toggle":
                    row = connection.execute(
                        "SELECT status FROM employees WHERE employee_id=?", (employee_id,)
                    ).fetchone()
                    if row is None:
                        raise ValueError("Employee not found.")
                    status = "inactive" if row["status"] == "active" else "active"
                    connection.execute(
                        "UPDATE employees SET status=? WHERE employee_id=?", (status, employee_id)
                    )
                    return {"ok": True, "status": status}
                if action != "save":
                    raise ValueError("Choose a valid employee action.")
                first_name = self._person_name(
                    self._text(body, "first_name", "First name"), "First name"
                )
                last_name = self._person_name(
                    self._text(body, "last_name", "Last name"), "Last name"
                )
                middle_name_value = body.get("middle_name", "")
                if not isinstance(middle_name_value, str):
                    raise ValueError("Enter a valid middle name.")
                middle_name = self._person_name(
                    middle_name_value.strip(), "Middle name", middle=True
                ) or None
                gender = self._text(body, "gender", "Gender")
                if gender not in ("Female", "Male", "Other"):
                    raise ValueError("Choose a supported gender.")
                department_value = body.get("department_id")
                if department_value in (None, ""):
                    raise ValueError("Department is required.")
                try:
                    department_id = int(department_value)
                except (TypeError, ValueError) as exc:
                    raise ValueError("Choose a valid department.") from exc
                position = self._text(body, "position", "Position")
                if connection.execute(
                    "SELECT 1 FROM department_positions "
                    "WHERE department_id=? AND position_name=?",
                    (department_id, position),
                ).fetchone() is None:
                    raise ValueError("Choose a position listed for the selected department.")
                hourly_rate = self._number(body.get("hourly_rate"), "Hourly rate")
                if hourly_rate <= 0:
                    raise ValueError("Hourly rate must be greater than 0.")
                if hourly_rate > 999.99 or round(hourly_rate, 2) != hourly_rate:
                    raise ValueError(
                        "Hourly rate must be no more than 999.99 with at most two decimal places."
                    )
                scheduled_start = self._text(body, "scheduled_start_time", "Shift start time")
                scheduled_end = self._text(body, "scheduled_end_time", "Shift end time")
                try:
                    datetime.strptime(scheduled_start, "%H:%M")
                    datetime.strptime(scheduled_end, "%H:%M")
                    if scheduled_start == scheduled_end:
                        raise ValueError
                except ValueError as exc:
                    raise ValueError("Enter different shift start and end times in HH:MM format.") from exc
                hire_date = self._date(self._text(body, "hire_date", "Hire date"), "hire date")
                birth_date = self._date(self._text(body, "birth_date", "Birth date"), "birth date")
                birth = date.fromisoformat(birth_date)
                today = date.today()
                age = today.year - birth.year - (
                    (today.month, today.day) < (birth.month, birth.day)
                )
                if age < MINIMUM_EMPLOYEE_AGE:
                    raise ValueError(
                        f"Employees must be at least {MINIMUM_EMPLOYEE_AGE} years old."
                    )
                contact_number = self._text(body, "contact_number", "Contact number")
                if (
                    len(contact_number) != 11
                    or not contact_number.isascii()
                    or not contact_number.isdigit()
                    or not contact_number.startswith("09")
                ):
                    raise ValueError(
                        "Enter an 11-digit mobile number starting with 09."
                    )
                email = self._text(body, "email", "Email")
                if "@" not in email:
                    raise ValueError("Email must contain an '@' symbol.")
                self._ensure_unique_employee_email(connection, email, employee_id)
                address = self._text(body, "address", "Address")
                personal_fields = (
                    "pagibig_number",
                    "sss_number",
                    "tax_identification_number",
                    "philhealth_number",
                    "emergency_contact_name",
                    "emergency_contact_number",
                )
                personal_labels = {
                    "pagibig_number": "Pag-IBIG number",
                    "sss_number": "SSS number",
                    "tax_identification_number": "Tax identification number",
                    "philhealth_number": "PhilHealth number",
                    "emergency_contact_name": "Emergency contact name",
                    "emergency_contact_number": "Emergency contact number",
                }
                number_limits = {
                    "pagibig_number": (12, (12,)),
                    "sss_number": (10, (10,)),
                    "tax_identification_number": (12, (9, 12)),
                    "philhealth_number": (12, (12,)),
                    "emergency_contact_number": (11, (11,)),
                }
                personal_values: list[str | None] = []
                for field in personal_fields:
                    if not employee_id:
                        value = self._text(body, field, personal_labels[field])
                    else:
                        value = body.get(field, "")
                        if not isinstance(value, str):
                            raise ValueError(f"Enter valid {personal_labels[field].lower()}.")
                        value = value.strip()
                    if len(value) > 200:
                        raise ValueError(f"{personal_labels[field]} must be 200 characters or fewer.")
                    if field == "emergency_contact_name" and value:
                        value = self._person_name(value, "Emergency contact name")
                    if field == "emergency_contact_number" and value and (
                        len(value) != 11
                        or not value.isascii()
                        or not value.isdigit()
                        or not value.startswith("09")
                    ):
                        raise ValueError(
                            "Enter an 11-digit emergency mobile number starting with 09."
                        )
                    if field in number_limits and value:
                        max_digits, valid_lengths = number_limits[field]
                        if any(character not in "0123456789-" for character in value):
                            raise ValueError(f"{personal_labels[field]} can contain only numbers and dashes.")
                        digit_count = sum(character.isdigit() for character in value)
                        if digit_count > max_digits:
                            raise ValueError(f"{personal_labels[field]} cannot exceed {max_digits} digits.")
                        if not employee_id and digit_count not in valid_lengths:
                            expected = "9 or 12" if field == "tax_identification_number" else str(valid_lengths[0])
                            raise ValueError(
                                f"{personal_labels[field]} must contain exactly {expected} digits."
                            )
                    personal_values.append(value or None)
                fields = (
                    first_name, last_name, middle_name, gender, birth_date, department_id, position,
                    "hourly", None, None, hourly_rate or None,
                    scheduled_start, scheduled_end, hire_date,
                    contact_number or None,
                    email or None,
                    address,
                    *personal_values,
                    self._text(body, "status", "Status").lower(),
                )
                if fields[-1] not in ("active", "inactive"):
                    raise ValueError("Choose active or inactive status.")
                if employee_id:
                    cursor = connection.execute(
                        "UPDATE employees SET first_name=?,last_name=?,middle_name=?,gender=?,birth_date=?,department_id=?,"
                        "position=?,salary_type=?,daily_rate=?,monthly_salary=?,hourly_rate=?,scheduled_start_time=?,"
                        "scheduled_end_time=?,hire_date=?,contact_number=?,email=?,address=?,pagibig_number=?,sss_number=?,"
                        "tax_identification_number=?,philhealth_number=?,emergency_contact_name=?,emergency_contact_number=?,"
                        "status=? WHERE employee_id=?",
                        fields + (employee_id,),
                    )
                    if cursor.rowcount == 0:
                        raise ValueError("Employee not found.")
                else:
                    connection.execute(
                        "INSERT INTO employees (first_name,last_name,middle_name,gender,birth_date,department_id,"
                        "position,salary_type,daily_rate,monthly_salary,hourly_rate,scheduled_start_time,"
                        "scheduled_end_time,hire_date,contact_number,email,address,pagibig_number,sss_number,"
                        "tax_identification_number,philhealth_number,emergency_contact_name,emergency_contact_number,status) "
                        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        fields,
                    )
        return {"ok": True}

    @staticmethod
    def _text(body: dict[str, Any], key: str, label: str) -> str:
        value = body.get(key)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{label} is required.")
        return value.strip()

    @staticmethod
    def _person_name(value: str, label: str, *, middle: bool = False) -> str:
        if not value and middle:
            return value
        allowed_punctuation = " ." if middle else " '-."
        if not value or not all(
            character.isalpha() or character in allowed_punctuation
            for character in value
        ):
            if middle:
                raise ValueError(
                    "Middle names can contain letters, spaces, and periods only."
                )
            raise ValueError(
                f"{label} can contain letters, spaces, apostrophes, hyphens, and periods only."
            )
        return value

    @staticmethod
    def _ensure_unique_employee_email(
        connection: sqlite3.Connection, email: str, employee_id: Any = None
    ) -> None:
        query = (
            "SELECT 1 FROM employees "
            "WHERE lower(trim(email))=lower(trim(?)) "
        )
        parameters: tuple[Any, ...] = (email,)
        if employee_id is not None:
            query += "AND employee_id != ? "
            parameters += (employee_id,)
        if connection.execute(query + "LIMIT 1", parameters).fetchone():
            raise ValueError("This email address is already assigned to another employee.")

    def _department_action(self, user: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
        self._require_role(user, ("admin",), "manage departments")
        action = body.get("action")
        with closing(db_manager.connect()) as connection:
            with connection:
                if action == "save":
                    name = self._text(body, "department_name", "Department name")
                    department_id = body.get("id")
                    if department_id:
                        connection.execute(
                            "UPDATE departments SET department_name=? WHERE department_id=?",
                            (name, department_id),
                        )
                    else:
                        connection.execute("INSERT INTO departments (department_name) VALUES (?)", (name,))
                elif action == "delete":
                    connection.execute("DELETE FROM departments WHERE department_id=?", (body.get("id"),))
                elif action == "save-position":
                    name = self._text(body, "position_name", "Position name")
                    department_id = int(body.get("department_id") or 0)
                    position_id = body.get("id")
                    if len(name) > 60:
                        raise ValueError("Position name must be 60 characters or fewer.")
                    if position_id:
                        connection.execute(
                            "UPDATE department_positions SET position_name=? WHERE position_id=? AND department_id=?",
                            (name, position_id, department_id),
                        )
                    else:
                        connection.execute(
                            "INSERT INTO department_positions (department_id,position_name) VALUES (?,?)",
                            (department_id, name),
                        )
                elif action == "delete-position":
                    connection.execute(
                        "DELETE FROM department_positions WHERE position_id=?",
                        (body.get("id"),),
                    )
                else:
                    raise ValueError("Choose a valid department action.")
        return {"ok": True}

    def _attendance_action(self, user: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
        self._require_role(user, ("admin", "hr"), "edit attendance")
        action = body.get("action")
        with closing(db_manager.connect()) as connection:
            with connection:
                if action == "delete":
                    connection.execute("DELETE FROM attendance WHERE attendance_id=?", (body.get("id"),))
                    return {"ok": True}
                if action != "save":
                    raise ValueError("Choose a valid attendance action.")
                employee_id = int(body.get("employee_id") or 0)
                work_date = self._date(body.get("date"), "work date")
                time_in = str(body.get("time_in", "")).strip() or None
                time_out = str(body.get("time_out", "")).strip() or None
                employee = connection.execute(
                    "SELECT scheduled_start_time,scheduled_end_time FROM employees "
                    "WHERE employee_id=? AND status='active'", (employee_id,)
                ).fetchone()
                if employee is None:
                    raise ValueError("Choose an active employee.")
                try:
                    hours, overtime = calculate_attendance_hours(
                        time_in, time_out,
                        str(employee["scheduled_start_time"] or "09:00"),
                        str(employee["scheduled_end_time"] or "17:00"),
                    )
                    late_minutes = calculate_late_minutes(
                        str(employee["scheduled_start_time"] or "09:00"), time_in
                    )
                except ValueError as exc:
                    raise ValueError(f"Invalid attendance time: {exc}") from exc
                record_id = body.get("id")
                duplicate = connection.execute(
                    "SELECT attendance_id FROM attendance WHERE employee_id=? AND date=? "
                    "AND attendance_id != ?",
                    (employee_id, work_date, record_id or -1),
                ).fetchone()
                if duplicate:
                    raise ValueError("This employee already has attendance recorded for that date.")
                values = (employee_id, work_date, time_in, time_out, hours, overtime, late_minutes)
                if record_id:
                    connection.execute(
                        "UPDATE attendance SET employee_id=?,date=?,time_in=?,time_out=?,hours_worked=?,"
                        "overtime_hours=?,late_minutes=? WHERE attendance_id=?",
                        values + (record_id,),
                    )
                else:
                    connection.execute(
                        "INSERT INTO attendance (employee_id,date,time_in,time_out,hours_worked,overtime_hours,late_minutes) "
                        "VALUES (?,?,?,?,?,?,?)", values,
                    )
        return {"ok": True}

    def _leave_action(self, user: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
        self._require_role(user, ("admin",), "manage leave records")
        action = body.get("action")
        with closing(db_manager.connect()) as connection:
            with connection:
                if action == "cancel":
                    cursor = connection.execute(
                        "UPDATE leave_records SET status='Cancelled' "
                        "WHERE leave_id=? AND status='Approved'",
                        (body.get("id"),),
                    )
                    if cursor.rowcount == 0:
                        raise ValueError("Only an approved leave record can be cancelled.")
                    return {"ok": True}
                if action == "remark":
                    note = body.get("remarks", "")
                    if not isinstance(note, str) or len(note) > 4000:
                        raise ValueError("Remarks must be 4,000 characters or fewer.")
                    cursor = connection.execute(
                        "UPDATE leave_records SET remarks=? WHERE leave_id=? AND status IN ('Approved','Cancelled')",
                        (note.strip() or None, body.get("id")),
                    )
                    if cursor.rowcount == 0:
                        raise ValueError("Only an approved or cancelled leave record can receive remarks.")
                    return {"ok": True}
                if action != "save":
                    raise ValueError("Leave records cannot be edited or deleted. Only remarks may be changed.")
                if body.get("id"):
                    raise ValueError("Approved leave records cannot be edited or deleted.")
                employee_id = int(body.get("employee_id") or 0)
                leave_type = str(body.get("leave_type", "")).strip()
                allowed = ("Paid leave", "Sick Leave", "Forced Leave", "Maternity leave", "Paternity leave", "Travel order")
                if leave_type not in allowed:
                    raise ValueError("Choose a supported leave type.")
                employee = connection.execute(
                    "SELECT gender FROM employees WHERE employee_id=? AND status='active'",
                    (employee_id,),
                ).fetchone()
                if employee is None:
                    raise ValueError("Choose an active employee.")
                gender = str(employee["gender"] or "").strip().lower()
                if leave_type == "Maternity leave" and gender != "female":
                    raise ValueError("Maternity leave is available only to employees registered as female.")
                if leave_type == "Paternity leave" and gender != "male":
                    raise ValueError("Paternity leave is available only to employees registered as male.")
                start = self._date(body.get("start_date"), "start date")
                end = self._date(body.get("end_date"), "end date")
                if end < start:
                    raise ValueError("The end date cannot be before the start date.")
                notes = str(body.get("notes", "")).strip() or None
                overlap = connection.execute(
                    "SELECT 1 FROM leave_records WHERE employee_id=? "
                    "AND status NOT IN ('Rejected','Cancelled') AND start_date<=? AND end_date>=?",
                    (employee_id, end, start),
                ).fetchone()
                if overlap:
                    raise ValueError("This leave record overlaps an existing non-cancelled leave or travel record.")
                connection.execute(
                    "INSERT INTO leave_records (employee_id,leave_type,start_date,end_date,status,notes) "
                    "VALUES (?,?,?,?,'Approved',?)",
                    (employee_id, leave_type, start, end, notes),
                )
        return {"ok": True}

    def _payroll_action(self, user: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
        self._require_role(user, ("admin", "accounting"), "manage payroll")
        action = body.get("action")
        if action == "delete":
            with closing(db_manager.connect()) as connection:
                with connection:
                    connection.execute("DELETE FROM payroll WHERE payroll_id=?", (body.get("id"),))
            return {"ok": True}
        if action == "deductions":
            employee_id = int(body.get("employee_id") or 0)
            amount = self._number(body.get("other", 0), "Other deduction")
            with closing(db_manager.connect()) as connection:
                with connection:
                    if not connection.execute("SELECT 1 FROM employees WHERE employee_id=?", (employee_id,)).fetchone():
                        raise ValueError("Choose a valid employee.")
                    connection.execute("DELETE FROM deductions WHERE employee_id=?", (employee_id,))
                    connection.execute(
                        "INSERT INTO deductions (employee_id,sss,philhealth,pagibig,tax,other) VALUES (?,0,0,0,0,?)",
                        (employee_id, amount),
                    )
            return {"ok": True}
        if action not in ("process", "preview"):
            raise ValueError("Choose a valid payroll action.")
        start = date.fromisoformat(self._date(body.get("period_start"), "period start"))
        end = date.fromisoformat(self._date(body.get("period_end"), "period end"))
        if end < start or not is_full_calendar_month(start, end):
            raise ValueError("Payroll must cover the first through last day of one calendar month.")
        with closing(db_manager.connect()) as connection:
            with connection:
                overlap = connection.execute(
                    "SELECT period_start,period_end FROM payroll WHERE period_start<=? AND period_end>=? LIMIT 1",
                    (end.isoformat(), start.isoformat()),
                ).fetchone()
                if overlap:
                    raise ValueError(
                        f"Payroll period overlaps an existing run ({overlap['period_start']} to {overlap['period_end']})."
                    )
                employees = connection.execute(
                    "SELECT employee_id,first_name,last_name,hourly_rate FROM employees "
                    "WHERE status='active' ORDER BY last_name,first_name"
                ).fetchall()
                if not employees:
                    raise ValueError("Add an active employee before processing payroll.")
                preview: list[tuple[Any, ...]] = []
                skipped: list[str] = []
                for employee in employees:
                    name = f"{employee['first_name']} {employee['last_name']}"
                    rate = float(employee["hourly_rate"] or 0)
                    if not math.isfinite(rate) or rate <= 0:
                        skipped.append(f"{name} (hourly rate not configured)")
                        continue
                    hours = connection.execute(
                        "SELECT COALESCE(SUM(MAX(0,COALESCE(hours_worked,0)-COALESCE(overtime_hours,0))),0) AS regular_hours,"
                        "COALESCE(SUM(MIN(COALESCE(overtime_hours,0),COALESCE(hours_worked,0))),0) AS overtime_hours,"
                        "COALESCE(SUM(late_minutes),0) AS late_minutes FROM attendance "
                        "WHERE employee_id=? AND date BETWEEN ? AND ?",
                        (employee["employee_id"], start.isoformat(), end.isoformat()),
                    ).fetchone()
                    attendance_dates = {
                        str(row["date"]) for row in connection.execute(
                            "SELECT date FROM attendance WHERE employee_id=? AND date BETWEEN ? AND ?",
                            (employee["employee_id"], start.isoformat(), end.isoformat()),
                        )
                    }
                    approved_leaves = connection.execute(
                        "SELECT start_date,end_date FROM leave_records WHERE employee_id=? "
                        "AND leave_type IN ('Paid leave','Sick Leave','Forced Leave','Travel order') "
                        "AND status='Approved' AND start_date<=? AND end_date>=?",
                        (employee["employee_id"], end.isoformat(), start.isoformat()),
                    ).fetchall()
                    paid_hours = calculate_paid_leave_hours(
                        [(str(row["start_date"]), str(row["end_date"])) for row in approved_leaves],
                        attendance_dates, start, end,
                    )
                    regular_hours = float(hours["regular_hours"] or 0) + paid_hours
                    overtime_hours = float(hours["overtime_hours"] or 0)
                    gross = round(calculate_hourly_gross(rate, regular_hours, overtime_hours), 2)
                    late_minutes = int(hours["late_minutes"] or 0)
                    tardiness = round(rate * late_minutes / 60, 2)
                    sss, philhealth, pagibig, tax = calculate_philippine_deductions(regular_hours * rate, gross)
                    other = connection.execute(
                        "SELECT COALESCE(other,0) AS total FROM deductions WHERE employee_id=? "
                        "ORDER BY deduction_id DESC LIMIT 1", (employee["employee_id"],)
                    ).fetchone()
                    other_amount = float(other["total"]) if other else 0
                    deductions = round(sss + philhealth + pagibig + tax + other_amount, 2)
                    if gross <= 0 or deductions + tardiness > gross or other_amount < 0:
                        skipped.append(f"{name} (no payable hours or deductions exceed gross)")
                        continue
                    preview.append((
                        int(employee["employee_id"]), gross, deductions, sss, philhealth, pagibig,
                        tax, other_amount, paid_hours, late_minutes, tardiness,
                        round(gross - deductions - tardiness, 2),
                    ))
                if not preview:
                    raise ValueError("No eligible employees. Check attendance, hourly rates, and deductions.")
                if action == "preview":
                    return {
                        "preview": True,
                        "processed": len(preview),
                        "skipped": skipped,
                        "gross": round(sum(row[1] for row in preview), 2),
                        "paid_leave_hours": round(sum(row[8] for row in preview), 2),
                        "late_minutes": sum(row[9] for row in preview),
                        "tardiness": round(sum(row[10] for row in preview), 2),
                        "deductions": round(sum(row[2] + row[10] for row in preview), 2),
                        "net": round(sum(row[11] for row in preview), 2),
                    }
                connection.executemany(
                    "INSERT INTO payroll (employee_id,period_start,period_end,gross_pay,deductions,sss_deduction,"
                    "philhealth_deduction,pagibig_deduction,tax_withheld,other_deductions,paid_leave_hours,"
                    "tardiness_minutes,tardiness_deduction,net_pay) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(row[0], start.isoformat(), end.isoformat(), *row[1:]) for row in preview],
                )
        return {
            "ok": True, "processed": len(preview), "skipped": skipped,
            "gross": round(sum(row[1] for row in preview), 2),
            "net": round(sum(row[11] for row in preview), 2),
        }

    def _request_action(self, user: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
        action = body.get("action")
        if action == "cancel":
            if user["role"] != "viewer":
                raise PermissionError("Only employees can cancel their own leave request.")
            leave_id = int(body.get("leave_id") or 0)
            with closing(db_manager.connect()) as connection:
                with connection:
                    cursor = connection.execute(
                        "UPDATE leave_records SET status='Cancelled' "
                        "WHERE leave_id=? AND employee_id=(SELECT employee_id FROM users WHERE id=?) "
                        "AND status='Approved'",
                        (leave_id, user["id"]),
                    )
                    if cursor.rowcount == 0:
                        raise ValueError("Only your approved leave can be cancelled.")
            return {"ok": True}
        if action == "submit":
            if user["role"] != "viewer":
                raise PermissionError("Only employee accounts can submit employee requests.")
            request_id = db_manager.submit_employee_request(
                int(user["id"]), str(body.get("request_type", "")), body.get("details", {})
            )
            return {"ok": True, "id": request_id}
        if action == "create-document":
            self._require_role(user, ("hr",), "create employee document records")
            try:
                employee_id = int(body.get("employee_id") or 0)
            except (TypeError, ValueError) as exc:
                raise ValueError("Choose a valid employee.") from exc
            request_id = db_manager.create_hr_document_record(
                employee_id,
                int(user["id"]),
                str(body.get("request_type", "")),
                body.get("details"),
            )
            return {"ok": True, "id": request_id}
        if action == "review":
            self._require_role(user, ("admin", "hr", "accounting"), "review employee requests")
            request_id = int(body.get("id") or 0)
            status = str(body.get("status", ""))
            db_manager.review_employee_request(
                request_id, int(user["id"]), status, str(body.get("review_note", ""))
            )
            return {"ok": True}
        raise ValueError("Choose a valid request action.")

    def _settings_action(self, user: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
        action = body.get("action")
        if action == "appearance":
            appearance = str(body.get("appearance_mode", ""))
            if appearance not in ("light", "dark"):
                raise ValueError("Choose light or dark appearance.")
            with closing(db_manager.connect()) as connection:
                with connection:
                    connection.execute(
                        "INSERT INTO app_settings (setting_key,setting_value) VALUES ('appearance_mode',?) "
                        "ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value",
                        (appearance,),
                    )
            return {"ok": True}
        self._require_role(user, ("admin",), "edit organization settings")
        if action == "restore":
            encoded = body.get("backup")
            if not isinstance(encoded, str) or not encoded:
                raise ValueError("Choose a payroll database backup file.")
            if len(encoded) > MAX_REQUEST_BYTES:
                raise ValueError("The database backup is too large to restore through the web app.")
            try:
                payload = base64.b64decode(encoded, validate=True)
            except (binascii.Error, ValueError) as exc:
                raise ValueError("The selected backup file is not valid base64 data.") from exc
            with tempfile.NamedTemporaryFile(suffix=".sqlite3", delete=False) as backup_file:
                backup_file.write(payload)
                backup_path = Path(backup_file.name)
            try:
                safety_backup = db_manager.restore_from(backup_path)
            finally:
                backup_path.unlink(missing_ok=True)
            with sessions_lock:
                sessions.clear()
            return {"ok": True, "restored": True, "safety_backup": safety_backup.name}
        if action == "delete":
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            database_path = db_manager.db_path.resolve()
            safety_backup = database_path.with_name(
                f"{database_path.stem}.before-delete-{timestamp}{database_path.suffix}"
            )
            db_manager.backup_to(safety_backup)
            db_manager.reset_database()
            with sessions_lock:
                sessions.clear()
            return {"ok": True, "deleted": True, "safety_backup": safety_backup.name}
        if action != "save":
            raise ValueError("Choose a valid settings action.")
        values = {
            "organization_name": self._text(body, "organization_name", "Organization name"),
            "organization_tagline": self._text(body, "organization_tagline", "Workspace tagline"),
            "currency_symbol": self._text(body, "currency_symbol", "Currency symbol"),
        }
        optional_fields = {
            "office_location": ("Office location", 200, ""),
            "hr_contact": ("HR contact", 200, ""),
            "work_days": ("Work days", 100, "Monday-Friday"),
            "office_start_time": ("Office start time", 5, "09:00"),
            "office_end_time": ("Office end time", 5, "17:00"),
            "company_policies": ("Company policies", 12000, ""),
        }
        for key, (label, max_length, default_value) in optional_fields.items():
            value = body.get(key, default_value)
            if not isinstance(value, str):
                raise ValueError(f"Enter valid {label.lower()}.")
            value = value.strip()
            if len(value) > max_length:
                raise ValueError(f"{label} must be {max_length} characters or fewer.")
            values[key] = value
        try:
            start_time = datetime.strptime(values["office_start_time"], "%H:%M")
            end_time = datetime.strptime(values["office_end_time"], "%H:%M")
        except ValueError as exc:
            raise ValueError("Enter office hours using 24-hour HH:MM time.") from exc
        if end_time <= start_time:
            raise ValueError("Office end time must be later than office start time.")
        try:
            break_minutes = int(body.get("break_duration_minutes", 60))
        except (TypeError, ValueError) as exc:
            raise ValueError("Enter a valid break duration in minutes.") from exc
        if not 0 <= break_minutes <= 180:
            raise ValueError("Break duration must be between 0 and 180 minutes.")
        values["break_duration_minutes"] = str(break_minutes)
        if values["currency_symbol"] not in ("₱", "$", "€", "£", "¥"):
            raise ValueError("Choose a supported currency symbol.")
        with closing(db_manager.connect()) as connection:
            with connection:
                connection.executemany(
                    "INSERT INTO app_settings (setting_key,setting_value) VALUES (?,?) "
                    "ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value",
                    list(values.items()),
                )
        return {"ok": True}

    def _account_action(self, user: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
        action = body.get("action")
        if action == "change-password":
            old_password = body.get("current_password")
            new_password = body.get("new_password")
            if not isinstance(old_password, str) or not isinstance(new_password, str):
                raise ValueError("Enter your current and new password.")
            if len(new_password) > MAX_PASSWORD_LENGTH:
                raise ValueError("New password is too long.")
            with closing(db_manager.connect()) as connection:
                with connection:
                    row = connection.execute(
                        "SELECT password_hash FROM users WHERE id=?", (user["id"],)
                    ).fetchone()
                    if row is None or not verify_password(old_password, str(row["password_hash"])):
                        raise ValueError("Your current password is incorrect.")
                    if len(new_password) < 8:
                        raise ValueError("Use at least 8 characters for the new password.")
                    connection.execute(
                        "UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?",
                        (hash_password(new_password), user["id"]),
                    )
            with sessions_lock:
                for session_id, (session_user, expires_at) in sessions.items():
                    if session_user["id"] == user["id"]:
                        sessions[session_id] = (
                            {**session_user, "mustChangePassword": False},
                            expires_at,
                        )
            return {"ok": True}
        if action == "review-password-reset":
            self._require_role(user, ("admin",), "review password reset requests")
            request_id = int(body.get("id") or 0)
            status = str(body.get("status", ""))
            new_password = body.get("new_password", "")
            if not isinstance(new_password, str):
                raise ValueError("Enter a temporary password.")
            reset_user_id = db_manager.review_password_reset_request(
                request_id,
                int(user["id"]),
                status,
                new_password,
            )
            if reset_user_id is not None:
                with sessions_lock:
                    for session_id, (session_user, _) in list(sessions.items()):
                        if session_user["id"] == reset_user_id:
                            sessions.pop(session_id, None)
            return {"ok": True}
        self._require_role(user, ("admin",), "manage user accounts")
        with closing(db_manager.connect()) as connection:
            with connection:
                if action == "create":
                    username = self._text(body, "username", "Username")
                    password = body.get("password")
                    role = str(body.get("role", ""))
                    if not isinstance(password, str) or len(password) < 8:
                        raise ValueError("Use at least 8 characters for the password.")
                    if len(password) > MAX_PASSWORD_LENGTH:
                        raise ValueError("Password is too long.")
                    if role not in ("admin", "hr", "accounting", "viewer"):
                        raise ValueError("Choose a supported account role.")
                    connection.execute(
                        "INSERT INTO users (username,password_hash,role) VALUES (?,?,?)",
                        (username, hash_password(password), role),
                    )
                elif action == "link":
                    account_id = int(body.get("id") or 0)
                    employee_id = int(body.get("employee_id") or 0)
                    cursor = connection.execute(
                        "UPDATE users SET employee_id=? WHERE id=? AND role IN ('hr','accounting','viewer')",
                        (employee_id, account_id),
                    )
                    if cursor.rowcount == 0:
                        raise ValueError("Choose a valid HR or employee account to link.")
                elif action == "unlink":
                    connection.execute(
                        "UPDATE users SET employee_id=NULL WHERE id=? AND role IN ('hr','accounting','viewer')",
                        (body.get("id"),),
                    )
                else:
                    raise ValueError("Choose a valid account action.")
        return {"ok": True}

    def _profile_user(self, user: dict[str, Any]) -> dict[str, Any]:
        with closing(db_manager.connect()) as connection:
            row = connection.execute(
                "SELECT profile_image, employee_id FROM users WHERE id=?", (user["id"],)
            ).fetchone()
            employee = None
            if row is not None and row["employee_id"] is not None:
                employee_row = connection.execute(
                    "SELECT first_name, middle_name, last_name, contact_number, email, address, "
                    "pagibig_number, sss_number, tax_identification_number, philhealth_number, "
                    "emergency_contact_name, emergency_contact_number "
                    "FROM employees WHERE employee_id=?",
                    (row["employee_id"],),
                ).fetchone()
                employee = dict(employee_row) if employee_row else None
        if row is None:
            raise ValueError("Your account could not be found.")
        image_data = bytes(row["profile_image"]) if row["profile_image"] else None
        mime_type = _profile_image_mime(image_data) if image_data else None
        profile_user = {
            **user,
            "profileImage": (
                f"data:{mime_type};base64,{base64.b64encode(image_data).decode('ascii')}"
                if mime_type and image_data
                else None
            ),
            "employee": employee,
        }
        with sessions_lock:
            for session_id, (session_user, expires_at) in sessions.items():
                if session_user["id"] == user["id"]:
                    sessions[session_id] = (profile_user, expires_at)
        return profile_user

    def _profile_action(self, user: dict[str, Any], body: dict[str, Any]) -> dict[str, Any]:
        if body.get("action") != "save":
            raise ValueError("Choose a valid profile action.")
        encoded_image = body.get("profile_image")
        image_data: bytes | None = None
        if encoded_image is not None:
            if not isinstance(encoded_image, str) or not encoded_image.startswith("data:"):
                raise ValueError("Choose a valid PNG, JPEG, GIF, or WebP profile photo.")
            header, separator, encoded = encoded_image.partition(",")
            mime_type = header.removeprefix("data:").removesuffix(";base64")
            if not separator or mime_type not in ("image/png", "image/jpeg", "image/gif", "image/webp"):
                raise ValueError("Choose a valid PNG, JPEG, GIF, or WebP profile photo.")
            try:
                image_data = base64.b64decode(encoded, validate=True)
            except (binascii.Error, ValueError) as exc:
                raise ValueError("The selected profile photo is invalid.") from exc
            if not image_data or len(image_data) > MAX_PROFILE_IMAGE_BYTES:
                raise ValueError("Choose a profile photo smaller than 5 MB.")
            if _profile_image_mime(image_data) != mime_type:
                raise ValueError("The selected file does not match its image format.")

        with closing(db_manager.connect()) as connection:
            with connection:
                exists = connection.execute(
                    "SELECT 1 FROM users WHERE id=?", (user["id"],)
                ).fetchone()
                if exists is None:
                    raise ValueError("Your account could not be found.")
                if "profile_image" in body:
                    connection.execute(
                        "UPDATE users SET profile_image=? WHERE id=?",
                        (sqlite3.Binary(image_data) if image_data is not None else None, user["id"]),
                    )
                employee_profile = body.get("employee")
                if employee_profile is not None:
                    if user["role"] != "viewer" or not isinstance(employee_profile, dict):
                        raise PermissionError("Only employees can update their own personal details.")
                    linked = connection.execute(
                        "SELECT employee_id FROM users WHERE id=?", (user["id"],)
                    ).fetchone()
                    if linked is None or linked["employee_id"] is None:
                        raise ValueError("Your account is not linked to an employee profile.")
                    profile_fields = (
                        "first_name",
                        "middle_name",
                        "last_name",
                        "contact_number",
                        "email",
                        "address",
                        "pagibig_number",
                        "sss_number",
                        "tax_identification_number",
                        "philhealth_number",
                        "emergency_contact_name",
                        "emergency_contact_number",
                    )
                    values: list[str | None] = []
                    for field in profile_fields:
                        value = employee_profile.get(field, "")
                        if not isinstance(value, str):
                            raise ValueError(f"Enter valid {field.replace('_', ' ')}.")
                        value = value.strip()
                        if field in ("first_name", "last_name"):
                            value = self._person_name(value, field.replace("_", " ").capitalize())
                        elif field == "middle_name":
                            value = self._person_name(value, "Middle name", middle=True)
                        elif field == "emergency_contact_name" and value:
                            value = self._person_name(value, "Emergency contact name")
                        if len(value) > 200:
                            raise ValueError(f"{field.replace('_', ' ').capitalize()} must be 200 characters or fewer.")
                        if field == "contact_number" and value and (
                            not value.isascii()
                            or not value.isdigit()
                            or len(value) != 11
                            or not value.startswith("09")
                        ):
                            raise ValueError(
                                "Enter an 11-digit mobile number starting with 09."
                            )
                        if field == "emergency_contact_number" and value and (
                            not value.isascii()
                            or not value.isdigit()
                            or len(value) != 11
                            or not value.startswith("09")
                        ):
                            raise ValueError(
                                "Enter an 11-digit emergency mobile number starting with 09."
                            )
                        if field == "email" and value and "@" not in value:
                            raise ValueError("Email must contain an '@' symbol.")
                        if field == "email" and value:
                            self._ensure_unique_employee_email(
                                connection, value, int(linked["employee_id"])
                            )
                        values.append(value or None)
                    assignments = ",".join(f"{field}=?" for field in profile_fields)
                    connection.execute(
                        f"UPDATE employees SET {assignments} WHERE employee_id=?",
                        (*values, linked["employee_id"]),
                    )

        updated_user = self._profile_user(user)
        with sessions_lock:
            for session_id, (session_user, expires_at) in sessions.items():
                if session_user["id"] == user["id"]:
                    sessions[session_id] = (updated_user, expires_at)
        return {"ok": True, "user": updated_user}

    def _read_json(self) -> dict[str, Any]:
        media_type = self.headers.get("Content-Type", "").partition(";")[0].strip().lower()
        if media_type != "application/json":
            raise ValueError("Request body must use application/json.")
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("Invalid request body.") from exc
        if content_length <= 0 or content_length > MAX_REQUEST_BYTES:
            raise ValueError("Request body is empty or too large.")
        try:
            raw_payload = self.rfile.read(content_length)
            if len(raw_payload) != content_length:
                raise ValueError("Request body is incomplete.")
            payload = json.loads(raw_payload)
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ValueError("Request body must be valid JSON.") from exc
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object.")
        return payload

    def _validate_request_origin(self) -> None:
        origin_header = self.headers.get("Origin")
        if not origin_header:
            raise PermissionError("Could not verify the request origin.")
        origin = urlsplit(origin_header)
        if (
            origin.scheme not in ("http", "https")
            or not origin.netloc
            or origin.path not in ("", "/")
            or origin.query
            or origin.fragment
            or origin.netloc.casefold() != self.headers.get("Host", "").casefold()
        ):
            raise PermissionError("Cross-origin requests are not allowed.")
        if self.headers.get("Sec-Fetch-Site", "").casefold() == "cross-site":
            raise PermissionError("Cross-origin requests are not allowed.")

    def _secure_cookie_attribute(self) -> str:
        if os.environ.get("PAYROLL_COOKIE_SECURE") == "1" or isinstance(self.connection, ssl.SSLSocket):
            return "; Secure"
        return ""

    def _login(self, body: dict[str, Any]) -> None:
        username = body.get("username")
        password = body.get("password")
        if not isinstance(username, str) or not isinstance(password, str):
            self._send_json(400, {"error": "Enter a username and password."})
            return
        if len(password) > MAX_PASSWORD_LENGTH:
            self._send_json(400, {"error": "Password is too long."})
            return
        with closing(db_manager.connect()) as connection:
            user = connection.execute(
                "SELECT id, username, password_hash, role, must_change_password "
                "FROM users WHERE username = ?",
                (username.strip(),),
            ).fetchone()
        if user is None or not verify_password(password, str(user["password_hash"])):
            self._send_json(401, {"error": "The username or password is incorrect."})
            return
        stored_hash = str(user["password_hash"])
        if password_needs_rehash(stored_hash):
            upgraded_hash = hash_password(password)
            with closing(db_manager.connect()) as connection:
                with connection:
                    connection.execute(
                        "UPDATE users SET password_hash=? WHERE id=? AND password_hash=?",
                        (upgraded_hash, user["id"], stored_hash),
                    )
        if user["role"] not in ("admin", "hr", "accounting", "viewer"):
            self._send_json(403, {"error": "This account has an unsupported role."})
            return

        session_id = secrets.token_urlsafe(32)
        current_user = {
            "id": int(user["id"]),
            "username": str(user["username"]),
            "role": str(user["role"]),
            "mustChangePassword": bool(user["must_change_password"]),
        }
        with sessions_lock:
            sessions[session_id] = (current_user, time.monotonic() + SESSION_SECONDS)
        current_user = self._profile_user(current_user)
        self._send_json(
            200,
            {"user": current_user},
            cookie=f"{SESSION_COOKIE}={session_id}; Path=/; HttpOnly; SameSite=Lax; Max-Age={SESSION_SECONDS}{self._secure_cookie_attribute()}",
        )

    def _submit_password_reset_request(self, body: dict[str, Any]) -> None:
        username = body.get("username")
        if not isinstance(username, str) or not username.strip():
            raise ValueError("Enter your username.")
        db_manager.submit_password_reset_request(username)
        self._send_json(
            200,
            {
                "ok": True,
                "message": (
                    "If the account exists, your request was submitted for administrator review. "
                    "The administrator will provide a temporary password after approval."
                ),
            },
        )

    def _logout(self) -> None:
        session_id = self._session_id()
        if session_id:
            with sessions_lock:
                sessions.pop(session_id, None)
        self._send_json(
            200,
            {"ok": True},
            cookie=f"{SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0{self._secure_cookie_attribute()}",
        )

    def _session_id(self) -> str | None:
        cookie = SimpleCookie()
        cookie.load(self.headers.get("Cookie", ""))
        morsel = cookie.get(SESSION_COOKIE)
        return morsel.value if morsel else None

    def _current_user(self) -> dict[str, Any] | None:
        session_id = self._session_id()
        if not session_id:
            return None
        with sessions_lock:
            session = sessions.get(session_id)
            if session is None:
                return None
            user, expires_at = session
            if expires_at <= time.monotonic():
                sessions.pop(session_id, None)
                return None
            sessions[session_id] = (user, time.monotonic() + SESSION_SECONDS)
            return user

    def _dashboard_data(self, user: dict[str, Any]) -> dict[str, Any]:
        today = date.today()
        if user["role"] == "viewer":
            with closing(db_manager.connect()) as connection:
                summary = connection.execute(
                    "SELECT COUNT(*) AS total, "
                    "SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS pending "
                    "FROM employee_requests WHERE submitted_by = ?",
                    (user["id"],),
                ).fetchone()
                profile = connection.execute(
                    "SELECT d.department_name, e.employee_code FROM users u "
                    "LEFT JOIN employees e ON e.employee_id = u.employee_id "
                    "LEFT JOIN departments d ON d.department_id = e.department_id "
                    "WHERE u.id = ?",
                    (user["id"],),
                ).fetchone()
            return {
                "role": user["role"],
                "today": today.isoformat(),
                "employeeView": True,
                "metrics": {
                    "requests": int(summary["total"] or 0),
                    "pendingRequests": int(summary["pending"] or 0),
                    "department": profile["department_name"] or "Unassigned",
                    "employeeCode": profile["employee_code"] or "",
                },
                "recentEmployees": [],
                "payrollHistory": [],
            }

        month_start, _ = _month_range(today.year, today.month)
        with closing(db_manager.connect()) as connection:
            metrics = connection.execute(
                "SELECT "
                "(SELECT COUNT(*) FROM employees WHERE status = 'active') AS active_employees, "
                "(SELECT COUNT(*) FROM departments) AS departments, "
                "(SELECT COUNT(*) FROM attendance WHERE date = ?) AS attendance_today, "
                "(SELECT COUNT(*) FROM employee_requests WHERE status = 'Pending') AS pending_requests, "
                "(SELECT COALESCE(SUM(net_pay), 0) FROM payroll "
                "WHERE period_start <= ? AND period_end >= ?) AS monthly_payroll",
                (today.isoformat(), today.isoformat(), month_start),
            ).fetchone()
            payroll_history: list[dict[str, Any]] = []
            for offset in range(5, -1, -1):
                month_index = today.year * 12 + today.month - 1 - offset
                year, month_zero = divmod(month_index, 12)
                month = month_zero + 1
                start, next_month_start = _month_range(year, month)
                result = connection.execute(
                    "SELECT COALESCE(SUM(net_pay), 0) AS total FROM payroll "
                    "WHERE period_start < ? AND period_end >= ?",
                    (next_month_start, start),
                ).fetchone()
                payroll_history.append(
                    {"month": date(year, month, 1).strftime("%b"), "total": float(result["total"] or 0)}
                )
            recent = connection.execute(
                "SELECT e.employee_id, e.employee_code, e.first_name, e.last_name, e.position, e.status, "
                "e.hire_date, d.department_name, u.profile_image IS NOT NULL AS has_profile_image "
                "FROM employees e "
                "LEFT JOIN departments d ON d.department_id = e.department_id "
                "LEFT JOIN users u ON u.employee_id = e.employee_id "
                "ORDER BY e.employee_id DESC LIMIT 6"
            ).fetchall()
        can_view_payroll = user["role"] in ("admin", "accounting")
        metrics_payload = {
            "activeEmployees": int(metrics["active_employees"]),
            "departments": int(metrics["departments"]),
            "attendanceToday": int(metrics["attendance_today"]),
            "pendingRequests": int(metrics["pending_requests"]),
        }
        if can_view_payroll:
            metrics_payload["monthlyPayroll"] = float(metrics["monthly_payroll"])
        return {
            "role": user["role"],
            "today": today.isoformat(),
            "employeeView": False,
            "metrics": metrics_payload,
            "payrollHistory": payroll_history if can_view_payroll else [],
            "recentEmployees": [
                {
                    "id": int(row["employee_id"]),
                    "employee_code": row["employee_code"],
                    "name": f"{row['first_name']} {row['last_name']}",
                    "position": row["position"] or "—",
                    "department": row["department_name"] or "Unassigned",
                    "status": row["status"],
                    "hireDate": row["hire_date"],
                    "profileImageUrl": (
                        f"/api/employees/{int(row['employee_id'])}/profile-image"
                        if row["has_profile_image"]
                        else None
                    ),
                }
                for row in recent
            ],
        }

    def _employees(self, query: str = "", sort: str = "name") -> list[dict[str, Any]]:
        with closing(db_manager.connect()) as connection:
            rows = connection.execute(
                "SELECT e.employee_id, e.first_name, e.middle_name, e.last_name, e.gender, "
                "e.employee_code, "
                "e.birth_date, e.department_id, e.position, e.salary_type, e.daily_rate, "
                "e.monthly_salary, e.hourly_rate, e.scheduled_start_time, e.scheduled_end_time, "
                "e.status, e.hire_date, e.email, e.contact_number, e.address, e.pagibig_number, e.sss_number, "
                "e.tax_identification_number, e.philhealth_number, e.emergency_contact_name, "
                "e.emergency_contact_number, d.department_name, "
                "u.profile_image IS NOT NULL AS has_profile_image "
                "FROM employees e "
                "LEFT JOIN departments d ON d.department_id = e.department_id "
                "LEFT JOIN users u ON u.employee_id = e.employee_id "
                "ORDER BY e.last_name COLLATE NOCASE, e.first_name COLLATE NOCASE"
            ).fetchall()
        employees = [
            {
                "id": int(row["employee_id"]),
                "employee_code": row["employee_code"],
                "first_name": row["first_name"],
                "middle_name": row["middle_name"] or "",
                "last_name": row["last_name"],
                "name": " ".join(
                    part for part in (row["first_name"], row["middle_name"], row["last_name"]) if part
                ),
                "gender": row["gender"] or "",
                "birth_date": row["birth_date"] or "",
                "department_id": row["department_id"],
                "position": row["position"] or "—",
                "salary_type": row["salary_type"] or "hourly",
                "daily_rate": row["daily_rate"],
                "monthly_salary": row["monthly_salary"],
                "hourly_rate": row["hourly_rate"],
                "scheduled_start_time": row["scheduled_start_time"] or "09:00",
                "scheduled_end_time": row["scheduled_end_time"] or "17:00",
                "department": row["department_name"] or "Unassigned",
                "status": row["status"],
                "hireDate": row["hire_date"],
                "hire_date": row["hire_date"] or "",
                "email": row["email"] or "",
                "contact_number": row["contact_number"] or "",
                "address": row["address"] or "",
                "pagibig_number": row["pagibig_number"] or "",
                "sss_number": row["sss_number"] or "",
                "tax_identification_number": row["tax_identification_number"] or "",
                "philhealth_number": row["philhealth_number"] or "",
                "emergency_contact_name": row["emergency_contact_name"] or "",
                "emergency_contact_number": row["emergency_contact_number"] or "",
                "profileImageUrl": (
                    f"/api/employees/{int(row['employee_id'])}/profile-image"
                    if row["has_profile_image"]
                    else None
                ),
            }
            for row in rows
        ]
        if sort not in ("name", "id"):
            raise ValueError("Choose a supported employee sort order.")

        employee_index: ChainedHashMap[int, dict[str, Any]] = ChainedHashMap(
            initial_capacity=max(8, len(employees))
        )
        for employee in employees:
            employee_index[employee["id"]] = employee

        normalized_query = query.strip()
        if normalized_query.casefold().startswith("id:"):
            identifier = normalized_query[3:].strip()
            if identifier.isdecimal():
                employee = employee_index.get(int(identifier))
                matches = [employee] if employee is not None else []
            elif identifier.upper().startswith("EMP-") and identifier[4:].isdecimal():
                matches = [
                    employee for employee in employees
                    if employee["employee_code"].casefold() == identifier.casefold()
                ]
            else:
                raise ValueError("Enter a numeric ID or an EMP-0001 code after ID:.")
        else:
            matches = linear_search_records(
                employees,
                normalized_query,
                lambda employee: (
                    employee["employee_code"],
                    employee["name"],
                    employee["department"],
                    employee["position"],
                    employee["email"],
                ),
            )

        return merge_sort_records(
            matches,
            key=(lambda employee: employee["id"])
            if sort == "id"
            else (lambda employee: employee["name"].casefold()),
        )

    def _send_json(
        self,
        status: int,
        payload: dict[str, Any],
        *,
        cookie: str | None = None,
    ) -> None:
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(encoded)

    def _download_backup(self, user: dict[str, Any]) -> None:
        self._require_role(user, ("admin",), "back up the payroll database")
        with closing(db_manager.connect()) as source, closing(sqlite3.connect(":memory:")) as backup:
            source.backup(backup)
            payload = backup.serialize()
        filename = f"payroll-backup-{datetime.now():%Y%m%d-%H%M%S}.sqlite3"
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.sqlite3")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def _send_employee_profile_image(self, user: dict[str, Any], employee_id: int) -> None:
        self._require_role(user, ("admin", "hr", "accounting"), "view employee profile photos")
        with closing(db_manager.connect()) as connection:
            row = connection.execute(
                "SELECT u.profile_image FROM users u WHERE u.employee_id=?",
                (employee_id,),
            ).fetchone()
        image_data = bytes(row["profile_image"]) if row and row["profile_image"] else None
        mime_type = _profile_image_mime(image_data) if image_data else None
        if image_data is None or mime_type is None:
            self._send_json(404, {"error": "Employee profile photo not found."})
            return
        self.send_response(200)
        self.send_header("Content-Type", mime_type)
        self.send_header("Content-Length", str(len(image_data)))
        self.send_header("Cache-Control", "private, no-store")
        self.end_headers()
        self.wfile.write(image_data)

    def log_message(self, format: str, *args: Any) -> None:
        logger.info(
            "%s %s %s %s",
            self.address_string(),
            self.command,
            urlsplit(self.path).path,
            getattr(self, "_response_status", "-"),
        )


def main() -> None:
    db_manager.initialize()
    address = ("127.0.0.1", 8000)
    server = ThreadingHTTPServer(address, PayrollRequestHandler)
    print("Payroll API listening on http://127.0.0.1:8000")
    if FRONTEND_DIST.is_dir():
        print("React app available at http://127.0.0.1:8000")
    else:
        print("Build the React app with `npm install` and `npm run build` in frontend.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping payroll server.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
