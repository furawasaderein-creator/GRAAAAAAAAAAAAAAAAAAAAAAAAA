import { Component, useCallback, useEffect, useRef, useState } from "react";
import WorkPages, { EmployeeAvatar } from "./WorkPages.jsx";
import onlineLogo from "./assets/lspu-online-logo.png";
import schoolLogo from "./assets/lspu-school-logo.png";

const currency = new Intl.NumberFormat("en-PH", {
  style: "currency",
  currency: "PHP",
  maximumFractionDigits: 0,
});

const dateLabel = (value, options = { weekday: "long", month: "long", day: "numeric", year: "numeric" }) =>
  new Intl.DateTimeFormat("en-PH", options).format(new Date(`${value}T00:00:00`));

async function request(path, options = {}) {
  const response = await fetch(path, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "Something went wrong.");
  return payload;
}

function Icon({ name, size = 20 }) {
  const paths = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></>,
    people: <><path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="10" cy="7" r="4" /><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 11h18" /></>,
    wallet: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M3 9h18M16 15h.01" /><path d="M6 5V3h12v2" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" /><path d="M10 21h4" /></>,
    arrow: <><path d="M7 17 17 7M7 7h10v10" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    reports: <><path d="M4 19V5M4 19h17" /><path d="m7 15 4-4 3 2 6-7" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.7a7 7 0 0 1-1.5.9l-.3 1.8h-2.8l-.3-1.8a7 7 0 0 1-1.5-.9l-1.7.7-1.4-2.4 1.4-1.1a7 7 0 0 1 0-1.8L6.9 12l1.4-2.4 1.7.7a7 7 0 0 1 1.5-.9l.3-1.8h2.8l.3 1.8a7 7 0 0 1 1.5.9l1.7-.7 1.4 2.4-1.4 1.1a7 7 0 0 1 0 1.9Z" transform="translate(-1 -1)" /></>,
    file: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6M8 13h8M8 17h8" /></>,
    logout: <><path d="M10 17l5-5-5-5M15 12H3" /><path d="M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6" /></>,
    close: <><path d="m18 6-12 12M6 6l12 12" /></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

function UserAvatar({ user, small = false }) {
  return <span className={`user-avatar ${small ? "small-avatar" : ""}`} aria-hidden="true">
    {user.profileImage ? <img src={user.profileImage} alt="" /> : user.username.slice(0, 1).toUpperCase()}
  </span>;
}

class PageRenderBoundary extends Component {
  state = { error: null };

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error, info) {
    console.error(`Could not render ${this.props.page}.`, error, info);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return <div className="alert-banner" role="alert">
      <span>Could not display {this.props.page}: {this.state.error.message || "An unexpected display error occurred."}</span>
      <button type="button" onClick={() => window.location.reload()}>Reload app</button>
    </div>;
  }
}

function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [recovering, setRecovering] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      await onLogin(username, password);
    } catch (loginError) {
      setError(loginError.message);
    } finally {
      setBusy(false);
    }
  }

  if (recovering) {
    return <PasswordRecovery onBack={() => setRecovering(false)} />;
  }

  return (
    <main className="auth-page">
      <AuthArtwork recovery={false} />
      <div className="auth-layout">
        <AuthBranding recovery={false} />
        <section className="auth-panel">
          <form className="auth-card" onSubmit={submit}>
            <div className="auth-wordmark"><img src={onlineLogo} alt="LSPU Online logo" /><span>LSPU<small>Payroll · System</small></span></div>
            <div className="auth-divider" />
            <label htmlFor="username">Username</label>
            <input id="username" autoComplete="username" value={username} onChange={(event) => setUsername(event.target.value)} placeholder="Enter your username" required />
            <div className="auth-password-label"><label htmlFor="password">Password</label></div>
            <input id="password" type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Enter your password" required />
            <button type="button" className="auth-text-button" onClick={() => setRecovering(true)}>Forgot password?</button>
            {error && <div className="auth-error" role="alert">{error}</div>}
            <button className="auth-submit" disabled={busy}>{busy ? "Signing in..." : "Login"} <span>→</span></button>
            <p className="auth-support">Need access? Contact your payroll administrator.</p>
          </form>
          <div className="auth-copyright">© {new Date().getFullYear()} LSPU · Human Resource &amp; Payroll Control Center</div>
        </section>
      </div>
    </main>
  );
}

function PasswordChangeRequired({ onSave, onLogout }) {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setError("");
    if (newPassword !== confirmPassword) {
      setError("The new passwords do not match.");
      return;
    }
    setBusy(true);
    try {
      await onSave(currentPassword, newPassword);
    } catch (saveError) {
      setError(saveError.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth-page">
      <AuthArtwork recovery />
      <div className="auth-layout">
        <AuthBranding recovery />
        <section className="auth-panel">
          <form className="auth-card" onSubmit={submit}>
            <div className="auth-wordmark"><img src={onlineLogo} alt="LSPU Online logo" /><span>LSPU<small>Payroll · System</small></span></div>
            <div className="auth-divider" />
            <h1>Set your new password</h1>
            <p className="auth-intro">Your administrator provided a temporary password. Replace it before continuing.</p>
            <label htmlFor="temporary-password">Temporary password</label>
            <input id="temporary-password" type="password" autoComplete="current-password" maxLength={1024} value={currentPassword} onChange={(event) => setCurrentPassword(event.target.value)} required />
            <label htmlFor="new-password">New password</label>
            <input id="new-password" type="password" autoComplete="new-password" minLength={8} maxLength={1024} value={newPassword} onChange={(event) => setNewPassword(event.target.value)} required />
            <label htmlFor="confirm-password">Confirm new password</label>
            <input id="confirm-password" type="password" autoComplete="new-password" minLength={8} maxLength={1024} value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} required />
            {error && <div className="auth-error" role="alert">{error}</div>}
            <button className="auth-submit" disabled={busy}>{busy ? "Updating password..." : "Update password"} <span>→</span></button>
            <button className="auth-back" type="button" onClick={onLogout}>Sign out</button>
          </form>
          <div className="auth-copyright">© {new Date().getFullYear()} LSPU · Human Resource &amp; Payroll Control Center</div>
        </section>
      </div>
    </main>
  );
}

function AuthArtwork({ recovery }) {
  return (
    <section className="auth-art" aria-hidden="true" data-recovery={recovery} />
  );
}

function AuthBranding({ recovery }) {
  return (
    <div className="auth-campus-card">
      <img className="auth-school-logo" src={schoolLogo} alt="Laguna State Polytechnic University seal" />
      <h2>{recovery ? <>RESET YOUR<br />EMPLOYEE ACCOUNT</> : <>HUMAN RESOURCE &amp;<br />PAYROLL CONTROL CENTER</>}</h2>
    </div>
  );
}

function PasswordRecovery({ onBack }) {
  const [username, setUsername] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setMessage("");
    setError("");
    setBusy(true);
    try {
      const result = await request("/api/password-reset-requests", {
        method: "POST",
        body: JSON.stringify({ username }),
      });
      setMessage(result.message);
    } catch (requestError) {
      setError(requestError.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth-page">
      <AuthArtwork recovery />
      <div className="auth-layout">
        <AuthBranding recovery />
        <section className="auth-panel">
          <form className="auth-card" onSubmit={submit}>
            <div className="auth-wordmark"><img src={onlineLogo} alt="LSPU Online logo" /><span>LSPU<small>Payroll · System</small></span></div>
            <div className="auth-divider" />
            <h1>Password Restoration</h1>
            <p className="auth-intro">Send a password reset request to your payroll administrator.</p>
            <label htmlFor="recovery-username">Username</label>
            <input id="recovery-username" autoComplete="username" value={username} onChange={(event) => setUsername(event.target.value)} placeholder="Enter your username" required />
            {message && <p className="auth-recovery-note" role="status">{message}</p>}
            {error && <div className="auth-error" role="alert">{error}</div>}
            <button className="auth-submit" type="submit" disabled={busy}>{busy ? "Sending request..." : "Send request"} <span>→</span></button>
            <button className="auth-back" type="button" onClick={onBack}>← Back to sign in</button>
          </form>
          <div className="auth-copyright">© {new Date().getFullYear()} LSPU · Human Resource &amp; Payroll Control Center</div>
        </section>
      </div>
    </main>
  );
}

function MetricCard({ label, value, note, icon, tone = "blue" }) {
  return (
    <article className={`metric-card tone-${tone}`}>
      <div className="metric-top"><span className="metric-label">{label}</span><span className="metric-icon"><Icon name={icon} size={19} /></span></div>
      <div className="metric-value">{value}</div>
      <div className="metric-note">{note}</div>
    </article>
  );
}

function PayrollChart({ history }) {
  const max = Math.max(1, ...history.map((item) => item.total));
  return (
    <section className="panel chart-panel">
      <div className="panel-heading">
        <div><h2>Payroll overview</h2><p>Net payroll processed over the last six months</p></div>
        <span className="chart-period"><span className="legend-dot" /> Net payroll</span>
      </div>
      {history.some((item) => item.total > 0) ? (
        <div className="chart" role="img" aria-label="Payroll totals by month">
          <div className="chart-grid"><span>{currency.format(max)}</span><span>{currency.format(max * 0.66)}</span><span>{currency.format(max * 0.33)}</span><span>₱0</span></div>
          <div className="chart-bars">{history.map((item) => (
            <div className="chart-column" key={`${item.month}-${item.total}`}>
              <span className="bar-value">{item.total ? currency.format(item.total) : "—"}</span>
              <div className="bar-track"><div className="bar" style={{ height: `${Math.max(item.total ? 5 : 0, (item.total / max) * 100)}%` }} /></div>
              <span className="bar-month">{item.month}</span>
            </div>
          ))}</div>
        </div>
      ) : <div className="empty-chart"><span className="empty-icon"><Icon name="wallet" size={22} /></span><strong>No payroll records yet</strong><span>Processed payroll will appear here over time.</span></div>}
    </section>
  );
}

function StatusBadge({ status }) {
  const normalized = String(status || "active").toLowerCase();
  return <span className={`status-badge ${normalized === "active" ? "status-active" : "status-inactive"}`}><i />{status || "Active"}</span>;
}

function EmployeeTable({ employees, compact = false }) {
  if (!employees.length) {
    return <div className="empty-table"><div className="empty-icon"><Icon name="people" size={22} /></div><strong>No employees to show</strong><span>Employees added to the payroll system will appear here.</span></div>;
  }
  return (
    <div className="table-scroll"><table><thead><tr><th>EMPLOYEE</th><th>DEPARTMENT</th><th>POSITION</th><th>STATUS</th>{!compact && <th>HIRED</th>}</tr></thead>
      <tbody>{employees.map((employee) => <tr key={employee.id}>
        <td><div className="employee-cell"><EmployeeAvatar employee={employee} /><div><strong>{employee.name}</strong><small>{employee.employee_code}</small></div></div></td>
        <td>{employee.department}</td><td>{employee.position}</td><td><StatusBadge status={employee.status} /></td>
        {!compact && <td>{employee.hireDate ? dateLabel(employee.hireDate, { month: "short", day: "numeric", year: "numeric" }) : "—"}</td>}
      </tr>)}</tbody>
    </table></div>
  );
}

function Dashboard({ data, onNavigate }) {
  const { metrics, employeeView } = data;
  const canViewPayroll = ["admin", "accounting"].includes(data.role);
  return (
    <>
      <section className="welcome-panel">
        <div className="welcome-copy"><span className="eyebrow"><span className="live-dot" /> YOUR PAYROLL, AT A GLANCE</span><h1>Good to see you again.</h1><p>Here’s what’s happening across your workspace today.</p></div>
        <div className="welcome-date"><Icon name="calendar" size={17} />{dateLabel(data.today)}</div>
        <div className="welcome-orb orb-one" /><div className="welcome-orb orb-two" />
      </section>
      <section className={`metric-grid ${employeeView ? "employee-metrics" : ""}`}>
        {employeeView ? <>
          <MetricCard label="MY REQUESTS" value={metrics.requests} note="Requests submitted" icon="people" />
          <MetricCard label="AWAITING REVIEW" value={metrics.pendingRequests} note="Pending with HR" icon="clock" tone="gold" />
          <MetricCard label="MY DEPARTMENT" value={metrics.department} note="Your employee profile" icon="grid" tone="green" />
          <MetricCard label="EMPLOYEE ID" value={metrics.employeeCode || "Not linked"} note="Your payroll employee number" icon="people" tone="purple" />
        </> : <>
          <MetricCard label="ACTIVE EMPLOYEES" value={metrics.activeEmployees.toLocaleString()} note="Current active workforce" icon="people" />
          <MetricCard label="DEPARTMENTS" value={metrics.departments.toLocaleString()} note="Organization units" icon="grid" tone="purple" />
          <MetricCard label="ATTENDANCE TODAY" value={metrics.attendanceToday.toLocaleString()} note={dateLabel(data.today, { month: "short", day: "numeric" })} icon="calendar" tone="green" />
          <MetricCard label="PENDING REQUESTS" value={metrics.pendingRequests.toLocaleString()} note="Awaiting HR review" icon="clock" tone="purple" />
          {canViewPayroll && <MetricCard label="PAYROLL THIS MONTH" value={currency.format(metrics.monthlyPayroll)} note="Net pay processed this month" icon="wallet" tone="gold" />}
        </>}
      </section>
      {!employeeView && canViewPayroll && <PayrollChart history={data.payrollHistory} />}
      <section className="panel recent-panel">
        <div className="panel-heading">
          <div><h2>{employeeView ? "Your request activity" : "Recent employees"}</h2><p>{employeeView ? "A quick look at your payroll workspace" : "The latest people added to your organization"}</p></div>
          {!employeeView && <button className="text-button" onClick={() => onNavigate("Employees")}>View directory <span>→</span></button>}
        </div>
        {employeeView ? <div className="employee-empty-note"><div className="empty-icon"><Icon name="clock" size={20} /></div><div><strong>Your requests are in one place</strong><span>Contact HR to submit a request or follow up on one.</span></div></div> : <EmployeeTable employees={data.recentEmployees} compact />}
      </section>
    </>
  );
}

function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("Dashboard");
  const [dashboard, setDashboard] = useState(null);
  const [sectionData, setSectionData] = useState(null);
  const [sectionDataPage, setSectionDataPage] = useState("");
  const [accounts, setAccounts] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sectionLoading, setSectionLoading] = useState(false);
  const [pageError, setPageError] = useState("");
  const [notice, setNotice] = useState("");
  const [mobileNav, setMobileNav] = useState(false);
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);
  const [openNavGroup, setOpenNavGroup] = useState(null);
  const accountMenuRef = useRef(null);
  const sectionRequestId = useRef(0);

  useEffect(() => {
    if (!accountMenuOpen) return undefined;
    function closeOnOutsideClick(event) {
      if (!accountMenuRef.current?.contains(event.target)) setAccountMenuOpen(false);
    }
    function handleMenuKeys(event) {
      if (event.key === "Escape") {
        setAccountMenuOpen(false);
        accountMenuRef.current?.querySelector(".account-menu-trigger")?.focus();
        return;
      }
      if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
      const menuItems = accountMenuRef.current?.querySelectorAll('[role="menuitem"]');
      if (!menuItems?.length) return;
      event.preventDefault();
      const currentIndex = Array.from(menuItems).indexOf(document.activeElement);
      const direction = event.key === "ArrowDown" ? 1 : -1;
      const nextIndex = currentIndex < 0
        ? (direction > 0 ? 0 : menuItems.length - 1)
        : (currentIndex + direction + menuItems.length) % menuItems.length;
      menuItems[nextIndex].focus();
    }
    document.addEventListener("mousedown", closeOnOutsideClick);
    document.addEventListener("keydown", handleMenuKeys);
    return () => {
      document.removeEventListener("mousedown", closeOnOutsideClick);
      document.removeEventListener("keydown", handleMenuKeys);
    };
  }, [accountMenuOpen]);

  useEffect(() => {
    if (!["admin", "hr", "accounting"].includes(user?.role)) return;
    if (["Employees", "Attendance", "Leaves", "Requests", "Documents"].includes(page)) {
      setOpenNavGroup("workforce");
    } else if (["Payroll", "Reports"].includes(page)) {
      setOpenNavGroup("payroll");
    }
  }, [user?.role, page]);

  const loadWorkspace = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setPageError("");
    try {
      const data = await request("/api/dashboard");
      setDashboard(data);
    } catch (error) {
      setPageError(error.message);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    let active = true;
    request("/api/session").then(({ user: sessionUser }) => {
      if (active) setUser(sessionUser);
    }).catch(() => {
      if (active) setUser(null);
    }).finally(() => {
      if (active) setLoading(false);
    });
    return () => { active = false; };
  }, []);

  useEffect(() => { loadWorkspace(); }, [loadWorkspace]);

  const loadSection = useCallback(async (section = page) => {
    if (!user || section === "Dashboard") return;
    const requestId = ++sectionRequestId.current;
    setSectionLoading(true);
    setPageError("");
    try {
      const data = await request(`/api/${section.toLowerCase()}`);
      if (requestId !== sectionRequestId.current) return;
      if (section === "Employees") {
        const extra = await request("/api/departments");
        if (requestId !== sectionRequestId.current) return;
        setSectionData({ ...data, ...extra });
      } else {
        setSectionData(data);
      }
      setSectionDataPage(section);
      if (section === "Accounts" && user.role === "admin") {
        setAccounts(data);
      } else {
        setAccounts(null);
      }
    } catch (error) {
      if (requestId === sectionRequestId.current) setPageError(error.message);
    } finally {
      if (requestId === sectionRequestId.current) setSectionLoading(false);
    }
  }, [page, user]);

  const searchEmployees = useCallback(async (query, sort) => {
    const params = new URLSearchParams({ query, sort });
    const result = await request(`/api/employees?${params}`);
    return result.employees;
  }, []);

  useEffect(() => {
    setSectionData(null);
    setSectionDataPage("");
    if (page === "Dashboard") {
      sectionRequestId.current += 1;
      setSectionLoading(false);
      return;
    }
    loadSection(page);
    return () => {
      sectionRequestId.current += 1;
    };
  }, [page, loadSection]);

  async function act(section, payload) {
    const result = await request(`/api/${section}`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
    if (result.deleted) {
      window.alert(`Database deleted and reset. A safety copy was saved as ${result.safety_backup}. Sign in with Admin / Admin123, then change the password immediately.`);
      setUser(null);
      setDashboard(null);
      setSectionData(null);
      setAccounts(null);
      setPage("Dashboard");
      return result;
    }
    if (result.restored) {
      window.alert(`Database restored successfully. A safety copy was saved as ${result.safety_backup}. Please sign in with an account from the restored database.`);
      setUser(null);
      setDashboard(null);
      setSectionData(null);
      setAccounts(null);
      setPage("Dashboard");
      return result;
    }
    if (payload.action === "preview") return result;
    if (section === "accounts" && payload.action === "review-password-reset" && payload.status === "Approved") {
      await loadSection(page);
      setNotice("Password reset approved. Share the temporary password securely; the user must change it when they sign in.");
      window.setTimeout(() => setNotice(""), 5000);
      return result;
    }
    if (section === "profile") {
      setUser((current) => current ? { ...current, ...result.user } : result.user);
      setNotice("Profile updated successfully.");
      window.setTimeout(() => setNotice(""), 3500);
      return result;
    }
    await loadSection(page);
    setNotice("Changes saved successfully.");
    window.setTimeout(() => setNotice(""), 3500);
    return result;
  }

  async function login(username, password) {
    const result = await request("/api/login", { method: "POST", body: JSON.stringify({ username, password }) });
    setPage("Dashboard");
    setUser(result.user);
  }

  async function changeRequiredPassword(currentPassword, newPassword) {
    await request("/api/accounts", {
      method: "POST",
      body: JSON.stringify({
        action: "change-password",
        current_password: currentPassword,
        new_password: newPassword,
      }),
    });
    setUser((current) => current ? { ...current, mustChangePassword: false } : current);
  }

  async function logout() {
    setPageError("");
    try {
      await request("/api/logout", { method: "POST", body: JSON.stringify({}) });
    } catch (error) {
      setPageError(`Could not sign out: ${error.message}`);
      return;
    }
    setUser(null);
    setDashboard(null);
    setSectionData(null);
    setAccounts(null);
    setPage("Dashboard");
  }

  function navigate(nextPage) {
    setPage(nextPage);
    setMobileNav(false);
    setAccountMenuOpen(false);
  }

  function openProfile() {
    setPage("Settings");
    setMobileNav(false);
    setAccountMenuOpen(false);
  }

  if (loading && !user) return <div className="app-loading"><span className="loading-mark">L</span><span>Opening your workspace…</span></div>;
  if (!user) return <Login onLogin={login} />;
  if (user.mustChangePassword) {
    return <PasswordChangeRequired onSave={changeRequiredPassword} onLogout={logout} />;
  }

  const isManager = user.role === "admin" || user.role === "hr";
  const canViewPayroll = user.role === "admin" || user.role === "accounting";
  const roleLabel = { admin: "Administrator", hr: "Human resources", accounting: "Accounting", viewer: "Employee" }[user.role] || user.role;
  const navEntries = [
    { type: "item", page: "Dashboard", label: "Overview", icon: "grid" },
    ...(isManager ? [
      { type: "group", id: "workforce", label: "Workforce", icon: "people", items: [
        { page: "Employees", label: "Employees", icon: "people" },
        { page: "Attendance", label: "Attendance", icon: "calendar" },
        { page: "Requests", label: "Requests", icon: "file" },
        { page: "Leaves", label: "Leave records", icon: "clock" },
        { page: "Documents", label: "Document records", icon: "file" },
      ] },
    ] : [
      ...(user.role === "accounting" ? [
        { type: "item", page: "Attendance", label: "Attendance", icon: "calendar" },
        { type: "item", page: "Requests", label: "Payslip requests", icon: "file" },
        { type: "item", page: "Documents", label: "Document records", icon: "file" },
      ] : [
        { type: "item", page: "Requests", label: "Requests", icon: "file" },
        { type: "item", page: "Documents", label: "My documents", icon: "file" },
      ]),
    ]),
    ...(canViewPayroll ? [{ type: "group", id: "payroll", label: "Payroll & reports", icon: "wallet", items: [
      { page: "Payroll", label: "Payroll", icon: "wallet" },
      { page: "Reports", label: "Reports & exports", icon: "reports" },
    ] }] : []),
    ...(user.role === "admin" ? [{ type: "item", page: "Accounts", label: "Accounts management", icon: "people" }] : []),
    { type: "item", page: "Settings", label: "Settings", icon: "settings" },
  ];

  return (
    <div className="app-shell">
      {mobileNav && <button className="nav-scrim" aria-label="Close navigation" onClick={() => setMobileNav(false)} />}
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand-lockup"><img className="brand-seal" src={schoolLogo} alt="Laguna State Polytechnic University seal" /><div><strong>LSPU</strong><span>PAYROLL SYSTEM</span></div></div>
        <div className="sidebar-section-label">WORKSPACE</div>
        <nav className="main-nav" aria-label="Main navigation">
          {navEntries.map((entry) => entry.type === "item"
            ? <button key={entry.page} className={`nav-item ${page === entry.page ? "nav-active" : ""}`} onClick={() => navigate(entry.page)}><Icon name={entry.icon} /><span>{entry.label}</span>{page === entry.page && <i />}</button>
            : <div className="nav-group" key={entry.id}>
              <button type="button" className={`nav-item nav-group-trigger ${entry.items.some((item) => item.page === page) ? "nav-group-active" : ""}`} aria-expanded={openNavGroup === entry.id} aria-controls={`nav-group-${entry.id}`} onClick={() => setOpenNavGroup((current) => current === entry.id ? null : entry.id)}>
                <Icon name={entry.icon} /><span>{entry.label}</span><span className={`nav-group-chevron ${openNavGroup === entry.id ? "is-open" : ""}`} aria-hidden="true">⌄</span>
              </button>
              {openNavGroup === entry.id && <div className="nav-submenu" id={`nav-group-${entry.id}`}>
                {entry.items.map((item) => <button key={item.page} className={`nav-item nav-subitem ${page === item.page ? "nav-active" : ""}`} onClick={() => navigate(item.page)}><Icon name={item.icon} size={17} /><span>{item.label}</span>{page === item.page && <i />}</button>)}
              </div>}
            </div>)}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-user"><UserAvatar user={user} /><div className="user-copy"><strong>{user.username}</strong><span>{roleLabel}</span></div><button className="logout-button" onClick={logout} aria-label="Sign out" title="Sign out"><Icon name="logout" size={18} /></button></div>
        </div>
      </aside>
      <main className="main-content">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setMobileNav(true)} aria-label="Open navigation"><span /><span /><span /></button>
          <div className="breadcrumb"><span>Workspace</span><b>/</b><strong>{page === "Dashboard" ? "Overview" : page}</strong></div>
          <div className="topbar-right"><span className="topbar-date">{dashboard ? dateLabel(dashboard.today, { month: "short", day: "numeric", year: "numeric" }) : ""}</span><span className="topbar-divider" />
            <div className="account-menu" ref={accountMenuRef}>
              <button className="account-menu-trigger" type="button" aria-haspopup="menu" aria-expanded={accountMenuOpen} onClick={() => setAccountMenuOpen((open) => !open)}>
                <UserAvatar user={user} small />
                <span className="account-menu-identity"><strong>{user.username}</strong><small>{roleLabel}</small></span>
                <span className={`account-menu-chevron ${accountMenuOpen ? "is-open" : ""}`} aria-hidden="true">⌄</span>
              </button>
              {accountMenuOpen && <div className="account-menu-popover" role="menu" aria-label="Account menu">
                <div className="account-menu-summary"><strong>{user.username}</strong><span>{roleLabel}</span></div>
                <button type="button" role="menuitem" onClick={openProfile}>Manage profile</button>
                <button type="button" role="menuitem" className="account-menu-signout" onClick={() => { setAccountMenuOpen(false); logout(); }}>Sign out</button>
              </div>}
            </div>
          </div>
        </header>
        <div className="content-wrap">
          {notice && <div className="success-banner" role="status">{notice}</div>}
          {pageError && <div className="alert-banner" role="alert"><span>{pageError}</span><button onClick={() => page === "Dashboard" ? loadWorkspace() : loadSection(page)}>Retry</button></div>}
          {!dashboard && !pageError && <div className="loading-state">Loading your workspace…</div>}
          {dashboard && page === "Dashboard" && <Dashboard data={dashboard} onNavigate={navigate} />}
          {page !== "Dashboard" && !pageError && <PageRenderBoundary key={page} page={page}><WorkPages page={page} data={sectionDataPage === page ? sectionData : null} loading={sectionLoading || sectionDataPage !== page} onAction={act} onReload={() => loadSection(page)} onSearchEmployees={searchEmployees} user={user} onNotify={setNotice} accounts={accounts} /></PageRenderBoundary>}
          <footer className="app-footer"><span>LSPU PAYROLL SYSTEM</span><span>Human Resource &amp; Payroll Control Center</span><span>v2.0</span></footer>
        </div>
      </main>
    </div>
  );
}

export default App;
