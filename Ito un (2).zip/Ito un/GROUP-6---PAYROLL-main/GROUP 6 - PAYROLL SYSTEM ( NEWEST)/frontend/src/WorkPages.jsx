import { useEffect, useMemo, useRef, useState } from "react";

const money = new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP", maximumFractionDigits: 2 });
const today = () => new Date().toISOString().slice(0, 10);
const MINIMUM_EMPLOYEE_AGE = 18;
const latestAllowedBirthDate = () => {
  const date = new Date();
  date.setFullYear(date.getFullYear() - MINIMUM_EMPLOYEE_AGE);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
};
const thisMonth = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
};
const text = (value) => value == null || value === "" ? "—" : String(value);

function PageHeader({ title, description, actions }) {
  return <div className="work-page-header"><div><span className="eyebrow"><span className="live-dot" /> PAYROLL WORKSPACE</span><h1>{title}</h1><p>{description}</p></div><div className="work-header-actions">{actions}</div></div>;
}

function ActionButton({ children, onClick, kind = "secondary", disabled = false }) {
  return <button type="button" className={`work-button ${kind}`} onClick={onClick} disabled={disabled}>{children}</button>;
}

export function EmployeeAvatar({ employee }) {
  const [imageError, setImageError] = useState(false);
  const initials = String(employee.name || "").split(/\s+/).map((part) => part[0]).slice(0, 2).join("").toUpperCase();
  return <span className="avatar" aria-hidden="true">
    {employee.profileImageUrl && !imageError
      ? <img src={employee.profileImageUrl} alt="" onError={() => setImageError(true)} />
      : initials}
  </span>;
}

function Table({ columns, rows, empty, renderActions, rowClassName }) {
  if (!rows.length) return <div className="work-empty"><span className="empty-icon">◎</span><strong>{empty}</strong></div>;
  return <div className="table-scroll"><table className="work-table"><thead><tr>{columns.map((column) => <th key={column.key}>{column.label}</th>)}{renderActions && <th>ACTIONS</th>}</tr></thead><tbody>
    {rows.map((row, index) => <tr className={rowClassName?.(row) || ""} key={row.id ?? index}>{columns.map((column) => <td key={column.key}>{column.render ? column.render(row) : text(row[column.key])}</td>)}{renderActions && <td><div className="row-actions">{renderActions(row)}</div></td>}</tr>)}
  </tbody></table></div>;
}

function FormDialog({ title, fields, initial = {}, onSave, onClose, submitLabel = "Save changes" }) {
  const [values, setValues] = useState(() => Object.fromEntries(fields.map((field) => [field.name, initial[field.name] ?? field.defaultValue ?? ""])));
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const update = (name, value) => setValues((current) => ({ ...current, [name]: value }));
  async function submit(event) {
    event.preventDefault();
    setSaving(true);
    setError("");
    try {
      await onSave(values);
      onClose();
    } catch (saveError) {
      setError(saveError.message);
    } finally {
      setSaving(false);
    }
  }
  return <div className="dialog-scrim" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <form className="work-dialog" onSubmit={submit}>
      <div className="dialog-heading"><div><span className="form-eyebrow">PAYROLL WORKSPACE</span><h2>{title}</h2></div><button type="button" className="dialog-close" onClick={onClose} aria-label="Close">×</button></div>
      <div className="dialog-fields">{fields.map((field) => {
        const options = typeof field.options === "function" ? field.options(values) : field.options;
        const value = values[field.name] ?? "";
        return <label className={`form-field ${field.wide ? "field-wide" : ""}`} key={field.name}><span>{field.label}{field.required && <i> *</i>}</span>
          {field.type === "textarea" ? <textarea value={value} required={field.required} rows={field.rows || 3} placeholder={field.placeholder || ""} onChange={(event) => update(field.name, event.target.value)} />
            : field.type === "select" ? <select required={field.required} value={value} onChange={(event) => update(field.name, event.target.value)}><option value="">Select…</option>{(options || []).map((option) => <option key={String(option.value)} value={option.value}>{option.label}</option>)}</select>
              : <input type={field.type || "text"} value={value} required={field.required} min={field.min} max={field.max} minLength={field.minLength} maxLength={field.maxLength} step={field.step} inputMode={field.inputMode} placeholder={field.placeholder || ""} onChange={(event) => {
                const input = event.currentTarget;
                const digitPosition = field.formatDigits
                  ? input.value.slice(0, input.selectionStart ?? input.value.length).replace(/\D/g, "").length
                  : 0;
                const nextValue = field.filter ? field.filter(input.value, value) : input.value;
                update(field.name, nextValue);
                if (field.formatDigits) {
                  requestAnimationFrame(() => {
                    if (!input.isConnected || document.activeElement !== input) return;
                    let position = 0;
                    let digits = 0;
                    while (position < nextValue.length && digits < digitPosition) {
                      if (/\d/.test(nextValue[position])) digits += 1;
                      position += 1;
                    }
                    if (nextValue[position] === "-") position += 1;
                    input.setSelectionRange(position, position);
                  });
                }
              }} />}
          {field.help && <small>{field.help}</small>}
        </label>;
      })}</div>
      {error && <div className="form-error" role="alert">{error}</div>}
      <div className="dialog-actions"><ActionButton onClick={onClose}>Cancel</ActionButton><button className="work-button primary" disabled={saving}>{saving ? "Saving…" : submitLabel}</button></div>
    </form>
  </div>;
}

const filterName = (value) => value.replace(/[^\p{L}\p{M} '-.]/gu, "");
const filterMiddleName = (value) => value.replace(/[^\p{L}\p{M} .]/gu, "");
const filterContactNumber = (value, current = "") => {
  const digits = value.replace(/\D/g, "").slice(0, 11);
  return !digits || "09".startsWith(digits) || digits.startsWith("09")
    ? digits
    : current;
};
const formatDigits = (value, groups) => {
  const maxDigits = groups.reduce((total, group) => total + group, 0);
  const digits = value.replace(/\D/g, "").slice(0, maxDigits);
  let offset = 0;
  const parts = [];
  for (const size of groups) {
    if (offset >= digits.length) break;
    parts.push(digits.slice(offset, offset + size));
    offset += size;
  }
  return parts.join("-");
};
const filterHourlyRate = (value, current) => {
  if (value === "") return value;
  if (!/^\d{1,3}(?:\.\d{0,2})?$/.test(value) || Number(value) > 999.99) return current;
  return value;
};
const employeeCode = (id) => `EMP-${String(Number(id || 0)).padStart(4, "0")}`;
const employeeNameWithCode = (name, id, code) => `${name || "Employee"} (${code || employeeCode(id)})`;
const employeeOption = (item) => {
  const id = item.id ?? item.employee_id;
  return { value: id, label: employeeNameWithCode(item.name || item.employee, id, item.employee_code) };
};

const employeeFields = (departments, positions) => [
  { name: "first_name", label: "First name", required: true, placeholder: "e.g. Juan", filter: filterName, help: "Letters, spaces, apostrophes, hyphens, and periods only." },
  { name: "last_name", label: "Last name", required: true, placeholder: "e.g. Dela Cruz", filter: filterName, help: "Letters, spaces, apostrophes, hyphens, and periods only." },
  { name: "middle_name", label: "Middle name", placeholder: "e.g. Santos", filter: filterMiddleName, help: "Optional. Letters, spaces, and periods only." },
  { name: "gender", label: "Gender", type: "select", required: true, options: ["Female", "Male", "Other"].map((value) => ({ value, label: value })) },
  { name: "birth_date", label: "Birth date", type: "date", required: true, max: latestAllowedBirthDate(), help: `Must be at least ${MINIMUM_EMPLOYEE_AGE} years old.` },
  { name: "department_id", label: "Department", type: "select", required: true, options: departments.map((item) => ({ value: item.department_id, label: item.department_name })) },
  { name: "position", label: "Position", type: "select", required: true, options: (values) => {
    const available = positions.filter((item) => !values.department_id || String(item.department_id) === String(values.department_id)).map((item) => item.position_name);
    return available.map((value) => ({ value, label: value }));
  } },
  { name: "hourly_rate", label: "Hourly rate (₱)", type: "number", required: true, min: "0.01", max: "999.99", step: "0.01", placeholder: "e.g. 150.00", filter: filterHourlyRate, help: "Must be greater than 0 and no more than ₱999.99 per hour." },
  { name: "scheduled_start_time", label: "Shift starts", type: "time", required: true, defaultValue: "09:00" },
  { name: "scheduled_end_time", label: "Shift ends", type: "time", required: true, defaultValue: "17:00" },
  { name: "hire_date", label: "Hire date", type: "date", required: true },
  { name: "contact_number", label: "Contact number", required: true, placeholder: "09XXXXXXXXX", filter: filterContactNumber, maxLength: 11, inputMode: "numeric", help: "Enter 11 digits starting with 09." },
  { name: "email", label: "Email", type: "email", required: true, placeholder: "name@example.com", help: "Must be unique for each employee." },
  { name: "pagibig_number", label: "Pag-IBIG number", required: true, placeholder: "0000-0000-0000", filter: (value) => formatDigits(value, [4, 4, 4]), formatDigits: true, maxLength: 14, inputMode: "numeric", help: "Enter 12 digits; dashes are added automatically." },
  { name: "sss_number", label: "SSS number", required: true, placeholder: "00-0000000-0", filter: (value) => formatDigits(value, [2, 7, 1]), formatDigits: true, maxLength: 12, inputMode: "numeric", help: "Enter 10 digits; dashes are added automatically." },
  { name: "tax_identification_number", label: "Tax identification number", required: true, placeholder: "000-000-000 or 000-000-000-000", filter: (value) => formatDigits(value, [3, 3, 3, 3]), formatDigits: true, maxLength: 15, inputMode: "numeric", help: "Enter 9 or 12 digits; dashes are added automatically." },
  { name: "philhealth_number", label: "PhilHealth number", required: true, placeholder: "00-000000000-0", filter: (value) => formatDigits(value, [2, 9, 1]), formatDigits: true, maxLength: 14, inputMode: "numeric", help: "Enter 12 digits; dashes are added automatically." },
  { name: "emergency_contact_name", label: "Emergency contact name", required: true, placeholder: "Full name", filter: filterName, help: "Letters, spaces, apostrophes, hyphens, and periods only." },
  { name: "emergency_contact_number", label: "Emergency contact number", required: true, placeholder: "09XXXXXXXXX", filter: filterContactNumber, maxLength: 11, inputMode: "numeric", help: "Enter 11 digits starting with 09." },
  { name: "status", label: "Status", type: "select", required: true, defaultValue: "active", options: [{ value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }] },
  { name: "address", label: "Address", type: "textarea", required: true, wide: true },
];

function EmployeesPage({ data, onAction, onReload, onSearchEmployees, canEdit, canManageDepartments }) {
  const [dialog, setDialog] = useState(null);
  const [query, setQuery] = useState("");
  const [filteredEmployees, setFilteredEmployees] = useState([]);
  const [searchError, setSearchError] = useState("");
  const [searching, setSearching] = useState(false);
  const [department, setDepartment] = useState(null);
  const [departmentForm, setDepartmentForm] = useState(null);
  const [positionForm, setPositionForm] = useState(null);
  const [sort, setSort] = useState("name");
  const employees = data?.employees || [];
  const departments = data?.departments || [];
  const positions = data?.positions || [];
  useEffect(() => {
    let active = true;
    const timer = window.setTimeout(async () => {
      setSearching(true);
      setSearchError("");
      try {
        const result = await onSearchEmployees(query, sort);
        if (active) setFilteredEmployees(result);
      } catch (error) {
        if (active) setSearchError(error.message);
      } finally {
        if (active) setSearching(false);
      }
    }, 150);
    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [employees, onSearchEmployees, query, sort]);
  const filtered = filteredEmployees;
  const fields = useMemo(() => employeeFields(departments, positions), [departments, positions]);
  const employeeColumns = [
    { key: "employee_code", label: "EMPLOYEE ID", render: (row) => <span className="employee-id-value">{row.employee_code}</span> },
    { key: "name", label: "EMPLOYEE", render: (row) => <div className="employee-cell"><EmployeeAvatar employee={row} /><div><strong>{row.name}</strong></div></div> },
    { key: "department", label: "DEPARTMENT" }, { key: "position", label: "POSITION" },
    { key: "rate", label: "HOURLY RATE", render: (row) => row.hourly_rate ? `${money.format(row.hourly_rate)} / hr` : "Not set" },
    { key: "status", label: "STATUS", render: (row) => <span className={`status-badge ${row.status === "active" ? "status-active" : "status-inactive"}`}><i />{row.status}</span> },
  ];
  return <>
    <PageHeader title="Employee directory" description="Create and maintain employee profiles, schedules, departments and pay rates."
      actions={canEdit && <ActionButton kind="primary" onClick={() => setDialog({})}>+ Add employee</ActionButton>} />
    <section className="panel directory-panel">
      <div className="directory-tools"><label className="search-field"><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search name, department, position, email, or ID:EMP-0001" /></label><select value={sort} onChange={(event) => setSort(event.target.value)} aria-label="Sort employees"><option value="name">Sort by name</option><option value="id">Sort by employee ID</option></select><span className="directory-count">{searching ? "Searching…" : `${filtered.length} employees`}</span></div>
      {searchError && <div className="form-error" role="alert">{searchError}</div>}
      <Table columns={employeeColumns} rows={filtered} empty="No employees yet. Add an employee to get started." renderActions={canEdit ? (row) => <><ActionButton onClick={() => setDialog(row)}>Edit</ActionButton><ActionButton onClick={async () => { await onAction("employees", { action: "toggle", id: row.id }); }}>Set {row.status === "active" ? "inactive" : "active"}</ActionButton><ActionButton kind="danger" onClick={async () => { if (window.confirm(`Delete ${row.name}?`)) await onAction("employees", { action: "delete", id: row.id }); }}>Delete</ActionButton></> : null} />
    </section>
    {canManageDepartments && <section className="panel sub-panel"><div className="panel-heading"><div><h2>Departments &amp; positions</h2><p>Keep employee assignments consistent across the organization.</p></div><ActionButton kind="primary" onClick={() => setDepartmentForm({})}>+ Add department</ActionButton></div>
      <Table columns={[{ key: "department_name", label: "DEPARTMENT" }, { key: "employee_count", label: "EMPLOYEES" }, { key: "positions", label: "POSITIONS", render: (row) => positions.filter((item) => item.department_id === row.department_id).map((item) => item.position_name).join(", ") || "No positions" }]} rows={departments} empty="No departments." renderActions={(row) => <><ActionButton onClick={() => setDepartment({ id: row.department_id, name: row.department_name })}>Manage positions</ActionButton><ActionButton onClick={() => setDepartmentForm(row)}>Rename</ActionButton><ActionButton kind="danger" onClick={async () => { if (window.confirm(`Delete department ${row.department_name}?`)) await onAction("departments", { action: "delete", id: row.department_id }); }}>Delete</ActionButton></>} />
    </section>}
    {dialog && <FormDialog title={dialog.id ? `Edit ${dialog.name}` : "Add employee"} fields={fields} initial={dialog} onClose={() => setDialog(null)} onSave={(values) => {
      if (!/^09\d{9}$/.test(String(values.contact_number || ""))) {
        throw new Error("Enter an 11-digit mobile number starting with 09.");
      }
      if (!/^09\d{9}$/.test(String(values.emergency_contact_number || ""))) {
        throw new Error("Enter an 11-digit emergency mobile number starting with 09.");
      }
      const email = String(values.email || "").trim().toLocaleLowerCase();
      const duplicateEmail = employees.some((employee) =>
        Number(employee.id) !== Number(dialog.id)
          && String(employee.email || "").trim().toLocaleLowerCase() === email
      );
      if (email && duplicateEmail) throw new Error("This email address is already assigned to another employee.");
      return onAction("employees", { ...values, action: "save", id: dialog.id });
    }} />}
    {departmentForm && <FormDialog title={departmentForm.department_id ? "Rename department" : "Add department"} fields={[{ name: "department_name", label: "Department name", required: true }]} initial={departmentForm} onClose={() => setDepartmentForm(null)} onSave={(values) => onAction("departments", { ...values, action: "save", id: departmentForm.department_id })} />}
    {department && <DepartmentPositions department={department} positions={positions.filter((item) => item.department_id === department.id)} onClose={() => setDepartment(null)} onAction={onAction} />}
  </>;
}

function DepartmentPositions({ department, positions, onClose, onAction }) {
  const [form, setForm] = useState(null);
  return <div className="dialog-scrim"><section className="work-dialog"><div className="dialog-heading"><div><span className="form-eyebrow">DEPARTMENT</span><h2>Positions · {department.name}</h2></div><button className="dialog-close" onClick={onClose}>×</button></div>
    <p className="dialog-description">Positions available for employees in this department.</p><Table columns={[{ key: "position_name", label: "POSITION" }]} rows={positions} empty="No positions added yet." renderActions={(row) => <><ActionButton onClick={() => setForm(row)}>Edit</ActionButton><ActionButton kind="danger" onClick={() => onAction("departments", { action: "delete-position", id: row.position_id })}>Delete</ActionButton></>} />
    <div className="dialog-actions"><ActionButton kind="primary" onClick={() => setForm({})}>+ Add position</ActionButton><ActionButton onClick={onClose}>Done</ActionButton></div></section>
    {form && <FormDialog title={form.position_id ? "Edit position" : "Add position"} fields={[{ name: "position_name", label: "Position name", required: true }]} initial={form} onClose={() => setForm(null)} onSave={(values) => onAction("departments", { ...values, action: "save-position", department_id: department.id, id: form.position_id })} />}
  </div>;
}

function AttendancePage({ data, onAction, canEdit }) {
  const [dialog, setDialog] = useState(null);
  const [filterDate, setFilterDate] = useState("");
  const [showSummary, setShowSummary] = useState(false);
  const employees = data?.employees || [];
  const records = (data?.records || []).filter((row) => !filterDate || row.date === filterDate);
  const summary = records.reduce((result, row) => ({
    hours: result.hours + Number(row.hours_worked || 0),
    overtime: result.overtime + Number(row.overtime_hours || 0),
    lateMinutes: result.lateMinutes + Number(row.late_minutes || 0),
  }), { hours: 0, overtime: 0, lateMinutes: 0 });
  function exportSummary() {
    const csvRows = [["Date", "Employee ID", "Employee", "Department", "Hours", "Overtime", "Late minutes"],
      ...records.map((row) => [row.date, row.employee_code, row.employee, row.department, row.hours_worked, row.overtime_hours, row.late_minutes])];
    const csv = csvRows.map((row) => row.map((value) => `"${String(value ?? "").replaceAll('"', '""')}"`).join(",")).join("\r\n");
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    link.download = `attendance-summary-${filterDate || "all-records"}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
  }
  const columns = [
    { key: "date", label: "DATE" },
    { key: "employee_code", label: "EMPLOYEE ID", render: (row) => <span className="employee-id-value">{row.employee_code || employeeCode(row.employee_id)}</span> },
    { key: "employee", label: "EMPLOYEE" },
    { key: "department", label: "DEPARTMENT" },
    { key: "time_in", label: "TIME IN" }, { key: "time_out", label: "TIME OUT" },
    { key: "hours_worked", label: "HOURS", render: (row) => Number(row.hours_worked || 0).toFixed(2) },
    { key: "overtime_hours", label: "OVERTIME", render: (row) => Number(row.overtime_hours || 0).toFixed(2) },
    { key: "late_minutes", label: "LATE (MIN)" },
  ];
  return <>
    <PageHeader title="Attendance records" description="Record worked hours, overtime and punctuality for each employee." actions={canEdit && <ActionButton kind="primary" onClick={() => setDialog({ date: today() })}>+ Record attendance</ActionButton>} />
    <section className="panel directory-panel"><div className="panel-heading directory-heading"><div><h2>Daily time records</h2><p>Overtime and tardiness are calculated using each employee’s shift schedule.</p></div><span className="directory-count">{records.length} records</span></div>
      <div className="directory-tools"><label className="form-field"><span>Work date</span><input type="date" value={filterDate} onChange={(event) => setFilterDate(event.target.value)} /></label><ActionButton onClick={() => setFilterDate("")}>Show all</ActionButton><ActionButton onClick={() => setShowSummary((current) => !current)}>{showSummary ? "Hide summary" : "Generate summary report"}</ActionButton>{showSummary && <ActionButton kind="primary" onClick={exportSummary}>Export CSV</ActionButton>}</div>
      {showSummary && <div className="report-metrics attendance-summary">
        {[["Attendance records", records.length], ["Hours worked", summary.hours.toFixed(2)], ["Overtime hours", summary.overtime.toFixed(2)], ["Late minutes", summary.lateMinutes]].map(([label, value]) => <article className="metric-card" key={label}><span className="metric-label">{label}</span><div className="metric-value">{value}</div></article>)}
      </div>}
      <Table columns={columns} rows={records} empty="No attendance records for this date." renderActions={canEdit ? (row) => <><ActionButton onClick={() => setDialog(row)}>Edit</ActionButton><ActionButton kind="danger" onClick={() => onAction("attendance", { action: "delete", id: row.id })}>Delete</ActionButton></> : null} />
    </section>
    {dialog && <FormDialog title={dialog.id ? "Edit attendance" : "Record attendance"} fields={[
      { name: "employee_id", label: "Employee", type: "select", required: true, options: employees.map(employeeOption), defaultValue: employees[0]?.id || "" },
      { name: "date", label: "Work date", type: "date", required: true, defaultValue: today() },
      { name: "time_in", label: "Time in", type: "time" }, { name: "time_out", label: "Time out", type: "time" },
    ]} initial={dialog} onClose={() => setDialog(null)} onSave={(values) => onAction("attendance", { ...values, action: "save", id: dialog.id })} />}
  </>;
}

function LeavesPage({ data, onAction, canEdit }) {
  const [dialog, setDialog] = useState(null);
  const [remarksDialog, setRemarksDialog] = useState(null);
  const [query, setQuery] = useState("");
  const employees = data?.employees || [];
  const allRecords = data?.records || [];
  const normalizedQuery = query.trim().toLocaleLowerCase();
  const records = allRecords.filter((row) => !normalizedQuery || [
    row.employee, row.employee_code, row.leave_type, row.status, row.notes, row.remarks,
  ].some((value) => String(value || "").toLocaleLowerCase().includes(normalizedQuery)));
  const columns = [
    { key: "employee", label: "EMPLOYEE", render: (row) => <span>{employeeNameWithCode(row.employee, row.employee_id, row.employee_code)}</span> }, { key: "leave_type", label: "TYPE" }, { key: "start_date", label: "START" },
    { key: "end_date", label: "END" }, { key: "status", label: "STATUS", render: (row) => { const status = String(row.status || "Unknown"); return <span className={`status-badge status-${status.toLowerCase()}`}><i />{status}</span>; } }, { key: "notes", label: "NOTES" }, { key: "remarks", label: "REMARKS" },
  ];
  return <>
    <PageHeader title="Leave records" description="Approved leave and travel requests are recorded here. Approved records stay read-only; remarks can be added for history." actions={canEdit && <ActionButton kind="primary" onClick={() => setDialog({ start_date: today(), end_date: today() })}>+ Add leave record</ActionButton>} />
    <section className="panel directory-panel"><div className="panel-heading directory-heading"><div><h2>Leave history</h2><p>Cancelled requests remain visible for audit history and are not counted in payroll.</p></div><span className="directory-count">{records.length} records</span></div>
      <div className="directory-tools"><label className="form-field"><span>Search leave records</span><input type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Employee, type, status, or remarks" /></label><ActionButton onClick={() => setQuery("")}>Clear search</ActionButton></div>
      <Table columns={columns} rows={records} empty="No matching leave records." rowClassName={(row) => row.status === "Cancelled" ? "cancelled-record" : ""} renderActions={canEdit ? (row) => <>{["Approved", "Cancelled"].includes(row.status) && <ActionButton onClick={() => setRemarksDialog(row)}>Add remarks</ActionButton>}{row.status === "Approved" && <ActionButton kind="danger" onClick={() => { if (window.confirm("Cancel this approved leave? It will remain visible in leave history.")) onAction("leaves", { action: "cancel", id: row.id }); }}>Cancel</ActionButton>}</> : null} />
    </section>
    {dialog && <FormDialog title="Add approved leave record" fields={[
      { name: "employee_id", label: "Employee", type: "select", required: true, options: employees.map(employeeOption), defaultValue: employees[0]?.id || "" },
      { name: "leave_type", label: "Leave type", type: "select", required: true, defaultValue: "Paid leave", options: ["Paid leave", "Sick Leave", "Forced Leave", "Maternity leave", "Paternity leave", "Travel order"].map((value) => ({ value, label: value })) },
      { name: "start_date", label: "Start date", type: "date", required: true, defaultValue: today() }, { name: "end_date", label: "End date", type: "date", required: true, defaultValue: today() },
      { name: "notes", label: "Notes", type: "textarea", wide: true },
    ]} initial={dialog} onClose={() => setDialog(null)} onSave={(values) => onAction("leaves", { ...values, action: "save", status: "Approved" })} />}
    {remarksDialog && <FormDialog title="Add remarks to approved leave" fields={[{ name: "remarks", label: "Remarks", type: "textarea", rows: 4, wide: true }]} initial={{ remarks: remarksDialog.remarks || "" }} onClose={() => setRemarksDialog(null)} onSave={(values) => onAction("leaves", { action: "remark", id: remarksDialog.id, remarks: values.remarks })} />}
  </>;
}

function PayrollPage({ data, onAction, canEdit }) {
  const [dialog, setDialog] = useState(null);
  const [deductionForm, setDeductionForm] = useState(null);
  const currentMonth = thisMonth();
  const [year, month] = currentMonth.split("-").map(Number);
  const lastDay = new Date(year, month, 0).getDate();
  const records = data?.records || [];
  const employees = data?.employees || [];
  const columns = [
    { key: "employee", label: "EMPLOYEE", render: (row) => <span>{employeeNameWithCode(row.employee, row.employee_id, row.employee_code)}</span> }, { key: "period_start", label: "PERIOD", render: (row) => `${row.period_start} – ${row.period_end}` },
    { key: "gross_pay", label: "GROSS", render: (row) => money.format(row.gross_pay) },
    { key: "paid_leave_hours", label: "PAID LEAVE", render: (row) => `${Number(row.paid_leave_hours || 0).toFixed(2)} hrs` },
    { key: "tardiness_deduction", label: "TARDINESS", render: (row) => money.format(row.tardiness_deduction) },
    { key: "deductions", label: "DEDUCTIONS", render: (row) => money.format(row.deductions) },
    { key: "net_pay", label: "NET PAY", render: (row) => <strong className="net-value">{money.format(row.net_pay)}</strong> },
  ];
  return <>
    <PageHeader title="Payroll" description="Review payroll history and run monthly calculations for active employees."
      actions={canEdit && <><ActionButton onClick={() => setDeductionForm({ employee_id: employees[0]?.id || "", other: "0" })}>Other deductions</ActionButton><ActionButton kind="primary" onClick={() => setDialog({ period_start: `${currentMonth}-01`, period_end: `${currentMonth}-${String(lastDay).padStart(2, "0")}` })}>Review &amp; process payroll →</ActionButton></>} />
    {canEdit && <div className="payroll-note"><strong>Monthly payroll run</strong><span>Regular hours at the hourly rate; overtime at 1.5×; paid leave and Philippine statutory deductions calculated automatically. Payroll runs must cover one complete calendar month.</span></div>}
    <section className="panel directory-panel"><div className="panel-heading directory-heading"><div><h2>Payroll history</h2><p>Processed employee records and net amounts.</p></div><span className="directory-count">{records.length} records</span></div>
      <Table columns={columns} rows={records} empty="No payroll runs yet." renderActions={canEdit ? (row) => <ActionButton kind="danger" onClick={() => { if (window.confirm(`Delete payroll record for ${row.employee} (${row.period_start} to ${row.period_end})?`)) onAction("payroll", { action: "delete", id: row.id }); }}>Delete</ActionButton> : null} />
    </section>
    {dialog && <FormDialog title="Review payroll period" submitLabel="Process payroll" fields={[
      { name: "period_start", label: "Period start", type: "date", required: true },
      { name: "period_end", label: "Period end", type: "date", required: true },
    ]} initial={dialog} onClose={() => setDialog(null)} onSave={async (values) => {
      const preview = await onAction("payroll", { ...values, action: "preview" });
      const skipped = preview.skipped.length ? `\nSkipped employees: ${preview.skipped.join("; ")}` : "";
      if (!window.confirm(
        `Payroll preview · ${values.period_start} to ${values.period_end}\n\n` +
        `Employees included: ${preview.processed}\nGross pay: ${money.format(preview.gross)}\n` +
        `Paid leave / travel: ${preview.paid_leave_hours.toFixed(2)} hours\n` +
        `Late minutes: ${preview.late_minutes}\nTardiness: ${money.format(preview.tardiness)}\n` +
        `Total deductions: ${money.format(preview.deductions)}\nNet payroll: ${money.format(preview.net)}` +
        `${skipped}\n\nProcess this payroll run?`,
      )) return;
      const result = await onAction("payroll", { ...values, action: "process" });
      window.alert(`Processed ${result.processed} employee(s). Net payroll: ${money.format(result.net)}${result.skipped?.length ? `\nSkipped: ${result.skipped.join("; ")}` : ""}`);
    }} />}
    {deductionForm && <FormDialog title="Optional other deductions" fields={[
      { name: "employee_id", label: "Employee", type: "select", required: true, options: employees.map(employeeOption), defaultValue: employees[0]?.id || "" },
      { name: "other", label: "Monthly amount (₱)", type: "number", min: "0", step: "0.01", required: true, defaultValue: "0" },
    ]} initial={deductionForm} onClose={() => setDeductionForm(null)} onSave={(values) => onAction("payroll", { ...values, action: "deductions" })} />}
  </>;
}

function ReportsPage({ onNotify }) {
  const [range, setRange] = useState(() => {
    const now = new Date();
    return { start: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`, end: today() };
  });
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  async function load() {
    setLoading(true);
    setError("");
    try {
      const query = new URLSearchParams(range);
      const response = await fetch(`/api/reports?${query}`, { credentials: "same-origin" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Could not load reports.");
      setData(result);
    } catch (loadError) {
      setError(loadError.message);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); }, []);
  function exportCsv() {
    if (!data?.records.length) return;
    const columns = ["employee_code", "employee", "department", "period_start", "period_end", "gross_pay", "sss_deduction", "philhealth_deduction", "pagibig_deduction", "tax_withheld", "other_deductions", "paid_leave_hours", "tardiness_minutes", "tardiness_deduction", "deductions", "net_pay", "generated_at"];
    const csv = [columns.join(","), ...data.records.map((row) => columns.map((key) => `"${String(row[key] ?? "").replaceAll('"', '""')}"`).join(","))].join("\r\n");
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    link.download = `payroll-report-${range.start}-to-${range.end}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
    onNotify("Payroll CSV exported.");
  }
  return <>
    <PageHeader title="Reports & exports" description="Review payroll totals and export the underlying records." actions={<ActionButton kind="primary" disabled={!data?.records.length} onClick={exportCsv}>Export payroll CSV ↓</ActionButton>} />
    <section className="panel report-filter"><label className="form-field"><span>From</span><input type="date" value={range.start} onChange={(event) => setRange({ ...range, start: event.target.value })} /></label><label className="form-field"><span>To</span><input type="date" value={range.end} onChange={(event) => setRange({ ...range, end: event.target.value })} /></label><ActionButton kind="primary" onClick={load}>Run report</ActionButton></section>
    {error && <div className="alert-banner">{error}</div>}
    <section className="report-metrics">{[["Payroll records", data?.totals.records ?? "—"], ["Gross pay", data ? money.format(data.totals.gross) : "—"], ["All deductions", data ? money.format(data.totals.deductions) : "—"], ["Net pay", data ? money.format(data.totals.net) : "—"]].map(([label, value]) => <article className="metric-card" key={label}><span className="metric-label">{label}</span><div className="metric-value">{loading ? "…" : value}</div></article>)}</section>
    <section className="panel directory-panel"><div className="panel-heading directory-heading"><div><h2>Payroll records</h2><p>{data ? `${data.start} through ${data.end}` : "Select a date range to run a report."}</p></div></div>
      <Table columns={[{ key: "employee", label: "EMPLOYEE", render: (row) => <span>{employeeNameWithCode(row.employee, row.employee_id, row.employee_code)}</span> }, { key: "department", label: "DEPARTMENT" }, { key: "period_start", label: "PERIOD", render: (row) => `${row.period_start} – ${row.period_end}` }, { key: "gross_pay", label: "GROSS", render: (row) => money.format(row.gross_pay) }, { key: "deductions", label: "DEDUCTIONS", render: (row) => money.format(row.deductions) }, { key: "net_pay", label: "NET PAY", render: (row) => money.format(row.net_pay) }]} rows={data?.records || []} empty={loading ? "Loading payroll report…" : "No payroll records in this date range."} />
    </section>
  </>;
}

const REQUEST_FIELDS = {
  Leave: [["leave_type", "Leave type", "select"], ["start_date", "Start date", "date"], ["end_date", "End date", "date"], ["reason", "Reason", "textarea"]],
  "Travel Order": [["destination", "Destination", "text"], ["start_date", "Start date", "date"], ["end_date", "End date", "date"], ["purpose", "Purpose", "textarea"]],
  "Accomplishment Report": [["period_start", "Period start", "date"], ["period_end", "Period end", "date"], ["reason", "Reason for request", "textarea"], ["report", "Report", "textarea"]],
  Clearance: [["purpose", "Purpose", "text"], ["details", "Details", "textarea"]],
  "Pass Slip": [["date", "Date", "date"], ["time_out", "Time out", "time"], ["time_in", "Expected time in", "time"], ["reason", "Reason", "textarea"]],
  "Certificate of Employment (COE)": [["reason", "Reason for request", "textarea"], ["requested_details", "Other details to include in your COE", "textarea"]],
  Payslip: [["period_start", "Pay period start", "date"], ["period_end", "Pay period end", "date"]],
};

const HR_DOCUMENT_TYPES = ["Accomplishment Report", "Clearance", "Pass Slip", "Certificate of Employment (COE)"];
const APPROVED_DOCUMENT_TYPES = [...HR_DOCUMENT_TYPES, "Payslip"];

function RequestFormDialog({ data, onAction, onClose, documentMode = false }) {
  const [requestType, setRequestType] = useState(documentMode ? HR_DOCUMENT_TYPES[0] : "Leave");
  const [employeeId, setEmployeeId] = useState("");
  const [values, setValues] = useState({});
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const requestTypes = documentMode ? HR_DOCUMENT_TYPES : (data?.requestTypes || []);
  const leaveTypes = ["Paid leave", "Sick Leave", "Forced Leave", ...(data?.gender === "female" ? ["Maternity leave"] : []), ...(data?.gender === "male" ? ["Paternity leave"] : [])];
  const fields = REQUEST_FIELDS[requestType] || REQUEST_FIELDS.Leave;
  async function submit(event) {
    event.preventDefault();
    setSaving(true);
    setError("");
    try {
      await onAction("requests", documentMode
        ? { action: "create-document", employee_id: employeeId, request_type: requestType, details: values }
        : { action: "submit", request_type: requestType, details: values });
      onClose();
    } catch (submitError) {
      setError(submitError.message);
    } finally {
      setSaving(false);
    }
  }
  return <div className="dialog-scrim"><form className="work-dialog" onSubmit={submit}>
    <div className="dialog-heading"><div><span className="form-eyebrow">{documentMode ? "HR DOCUMENT RECORD" : "EMPLOYEE REQUEST"}</span><h2>{documentMode ? "Create document record" : "New request"}</h2></div><button type="button" className="dialog-close" onClick={onClose}>×</button></div>
    <div className="dialog-fields">{documentMode && <label className="form-field field-wide"><span>Employee</span><select value={employeeId} onChange={(event) => setEmployeeId(event.target.value)} required><option value="">Select an employee…</option>{(data?.employees || []).map((employee) => <option key={employee.id} value={employee.id}>{employeeOption(employee).label}</option>)}</select></label>}<label className="form-field field-wide"><span>{documentMode ? "Document type" : "Request type"}</span><select value={requestType} onChange={(event) => { setRequestType(event.target.value); setValues({}); }} required>{requestTypes.map((value) => <option key={value}>{value}</option>)}</select></label>
      {fields.map(([name, label, type]) => <label className={`form-field ${type === "textarea" ? "field-wide" : ""}`} key={`${requestType}-${name}`}><span>{label}</span>
        {name === "leave_type" ? <select required value={values[name] || "Paid leave"} onChange={(event) => setValues({ ...values, [name]: event.target.value })}>{leaveTypes.map((value) => <option key={value}>{value}</option>)}</select>
          : type === "textarea" ? <textarea required rows="3" value={values[name] || ""} onChange={(event) => setValues({ ...values, [name]: event.target.value })} />
            : <input required type={type} value={values[name] || ""} onChange={(event) => setValues({ ...values, [name]: event.target.value })} />}
      </label>)}
    </div>
    {error && <div className="form-error" role="alert">{error}</div>}
    <div className="dialog-actions"><ActionButton onClick={onClose}>Cancel</ActionButton><button className="work-button primary" disabled={saving}>{saving ? (documentMode ? "Creating…" : "Submitting…") : (documentMode ? "Create record" : "Submit request")}</button></div>
  </form></div>;
}

function RequestsPage({ data, onAction, user }) {
  const [dialog, setDialog] = useState(null);
  const [documentDialog, setDocumentDialog] = useState(false);
  const [selected, setSelected] = useState(null);
  const [reviewError, setReviewError] = useState("");
  const [reviewSaving, setReviewSaving] = useState(false);
  const viewer = user.role === "viewer";
  const visibleRequests = (data?.records || []).filter((row) =>
    row.status !== "Approved"
      || (!APPROVED_DOCUMENT_TYPES.includes(row.request_type)
        && (viewer || !["Leave", "Travel Order"].includes(row.request_type)))
  );
  const canReview = (row) => user.role === "admin"
    || (user.role === "hr" && !["Leave", "Travel Order", "Payslip"].includes(row.request_type))
    || (user.role === "accounting" && row.request_type === "Payslip");
  const columns = [
    { key: "employee", label: "EMPLOYEE", render: (row) => <span>{employeeNameWithCode(row.employee, row.employee_id, row.employee_code)}</span> }, { key: "department", label: "DEPARTMENT" },
    { key: "request_type", label: "REQUEST" }, { key: "submitted_at", label: "SUBMITTED" },
    { key: "status", label: "STATUS", render: (row) => { const status = row.leave_status === "Cancelled" ? "Cancelled" : row.status; return <span className={`status-badge status-${status.toLowerCase()}`}><i />{status}</span>; } },
  ];
  function requestDetails(row) {
    try { return JSON.parse(row.details); } catch { return {}; }
  }
  async function submitReview() {
    if (!selected?.review || reviewSaving) return;
    setReviewError("");
    setReviewSaving(true);
    try {
      const review_note = document.getElementById("review-note")?.value || "";
      await onAction("requests", { action: "review", id: selected.id, status: selected.review, review_note });
      setSelected(null);
    } catch (error) {
      setReviewError(error.message);
    } finally {
      setReviewSaving(false);
    }
  }
  return <>
    <PageHeader title="Employee requests" description={viewer ? "Submit requests and track their review status." : "Review employee requests and manage their outcomes."} actions={<>{viewer && data?.canSubmit && <ActionButton kind="primary" onClick={() => setDialog({ request_type: "Leave" })}>+ New request</ActionButton>}{user.role === "hr" && <ActionButton kind="primary" onClick={() => setDocumentDialog(true)}>+ Create document record</ActionButton>}</>} />
    {viewer && !data?.canSubmit && <div className="alert-banner">Your account is not linked to an employee profile. Contact an administrator before submitting requests.</div>}
    <section className="panel directory-panel"><div className="panel-heading directory-heading"><div><h2>{viewer ? "My requests" : "Requests for review"}</h2><p>{viewer ? "Your submitted requests and reviewer decisions." : "Select a request to review the submitted details."}</p></div><span className="directory-count">{visibleRequests.length} requests</span></div>
      <Table columns={columns} rows={visibleRequests} empty="No employee requests yet." renderActions={(row) => <><ActionButton onClick={() => { setReviewError(""); setSelected(row); }}>Details</ActionButton>{viewer && row.leave_id && row.leave_status === "Approved" && <ActionButton kind="danger" onClick={() => { if (window.confirm("Cancel this approved leave? The cancelled record will remain in leave history.")) onAction("requests", { action: "cancel", leave_id: row.leave_id }); }}>Cancel leave</ActionButton>}{!viewer && canReview(row) && row.status === "Pending" && <><ActionButton kind="primary" onClick={() => { setReviewError(""); setSelected({ ...row, review: "Approved" }); }}>Approve</ActionButton><ActionButton kind="danger" onClick={() => { setReviewError(""); setSelected({ ...row, review: "Rejected" }); }}>Reject</ActionButton></>}</>} />
    </section>
    {selected && <div className="dialog-scrim"><section className="work-dialog"><div className="dialog-heading"><div><span className="form-eyebrow">{selected.request_type}</span><h2>{selected.employee}</h2></div><button className="dialog-close" onClick={() => { setReviewError(""); setSelected(null); }} disabled={reviewSaving}>×</button></div>
      <dl className="request-details">{Object.entries(requestDetails(selected)).map(([key, value]) => <div key={key}><dt>{key.replaceAll("_", " ")}</dt><dd>{String(value)}</dd></div>)}{selected.review_note && <div><dt>Reviewer note</dt><dd>{selected.review_note}</dd></div>}</dl>
      {selected.payslip && <PayslipCard payslip={selected.payslip} />}
      {selected.review && <label className="form-field"><span>Reviewer note (optional)</span><textarea rows="3" id="review-note" /></label>}
      {reviewError && <div className="form-error" role="alert">{reviewError}</div>}
      <div className="dialog-actions"><ActionButton onClick={() => { setReviewError(""); setSelected(null); }} disabled={reviewSaving}>Close</ActionButton>{selected.review && <ActionButton kind={selected.review === "Approved" ? "primary" : "danger"} disabled={reviewSaving} onClick={submitReview}>{reviewSaving ? "Saving…" : `${selected.review} request`}</ActionButton>}</div>
    </section></div>}
    {dialog && <RequestFormDialog data={data} onAction={onAction} onClose={() => setDialog(null)} />}
    {documentDialog && <RequestFormDialog data={data} onAction={onAction} onClose={() => setDocumentDialog(false)} documentMode />}
  </>;
}

function PayslipCard({ payslip }) {
  const deductions = [
    ["SSS", payslip.sss_deduction],
    ["PhilHealth", payslip.philhealth_deduction],
    ["Pag-IBIG", payslip.pagibig_deduction],
    ["Tax", payslip.tax_withheld],
    ["Other deductions", payslip.other_deductions],
    ["Tardiness", payslip.tardiness_deduction],
  ];
  return <section className="payslip-card">
    <div className="payslip-heading"><div><span>EMPLOYEE PAYSLIP</span><h3>{payslip.employee}</h3></div><div><span>PAY PERIOD</span><strong>{payslip.period_start} – {payslip.period_end}</strong></div></div>
    <div className="payslip-columns"><section><h4>Earnings</h4><div className="payslip-row"><span>Gross pay</span><strong>{money.format(payslip.gross_pay)}</strong></div></section><section><h4>Deductions</h4>{deductions.map(([label, amount]) => <div className="payslip-row" key={label}><span>{label}</span><strong>{money.format(amount)}</strong></div>)}</section></div>
    <div className="payslip-net"><span>NET PAY</span><strong>{money.format(payslip.net_pay)}</strong></div>
    <div className="payslip-actions"><ActionButton onClick={() => window.print()}>Print payslip</ActionButton></div>
  </section>;
}

function AccountsPage({ data, onAction, onReload }) {
  const [accountDialog, setAccountDialog] = useState(false);
  const [linkDialog, setLinkDialog] = useState(null);
  const [resetRequest, setResetRequest] = useState(null);
  const [resetError, setResetError] = useState("");
  async function rejectResetRequest(id) {
    setResetError("");
    try {
      await onAction("accounts", { action: "review-password-reset", id, status: "Rejected" });
    } catch (error) {
      setResetError(error.message);
    }
  }
  return <>
    <PageHeader title="Accounts management" description="Manage staff and employee sign-ins, links, and password reset requests." actions={<ActionButton onClick={onReload}>Refresh</ActionButton>} />
    <section className="panel settings-card"><div className="panel-heading"><div><h2>User accounts</h2><p>Create staff and employee sign-ins, or link an employee profile.</p></div><ActionButton kind="primary" onClick={() => setAccountDialog(true)}>+ Create account</ActionButton></div>
      <Table columns={[{ key: "username", label: "USERNAME" }, { key: "role", label: "ROLE" }, { key: "employee", label: "LINKED EMPLOYEE", render: (row) => row.employee ? employeeNameWithCode(row.employee, row.employee_id, row.employee_code) : "—" }]} rows={data?.accounts || []} empty="No accounts." renderActions={(row) => ["hr", "accounting", "viewer"].includes(row.role) && <>{row.employee && <ActionButton onClick={() => onAction("accounts", { action: "unlink", id: row.id })}>Unlink</ActionButton>}<ActionButton onClick={() => setLinkDialog(row)}>{row.employee ? "Change link" : "Link employee"}</ActionButton></>} />
    </section>
    <section className="panel settings-card"><div className="panel-heading"><div><h2>Password reset requests</h2><p>Review employee requests and set a temporary password when approving.</p></div><ActionButton onClick={onReload}>Refresh requests</ActionButton></div>
      {resetError && <div className="form-error" role="alert">{resetError}</div>}
      <Table columns={[{ key: "username", label: "USERNAME" }, { key: "submitted_at", label: "SUBMITTED" }]} rows={data?.passwordResetRequests || []} empty="No pending password reset requests." renderActions={(row) => <><ActionButton kind="primary" onClick={() => setResetRequest(row)}>Approve &amp; set password</ActionButton><ActionButton kind="danger" onClick={() => rejectResetRequest(row.id)}>Reject</ActionButton></>} />
    </section>
    {accountDialog && <FormDialog title="Create user account" fields={[{ name: "username", label: "Username", required: true }, { name: "password", label: "Temporary password", type: "password", required: true, help: "At least 8 characters." }, { name: "role", label: "Role", type: "select", required: true, options: [{ value: "admin", label: "Administrator" }, { value: "hr", label: "HR" }, { value: "accounting", label: "Accounting" }, { value: "viewer", label: "Employee" }] }]} onClose={() => setAccountDialog(false)} onSave={(values) => onAction("accounts", { action: "create", ...values })} />}
    {linkDialog && <FormDialog title={`Link employee account · ${linkDialog.username}`} fields={[{ name: "employee_id", label: "Employee", type: "select", required: true, options: (data?.employees || []).map(employeeOption) }]} initial={{ employee_id: linkDialog.employee_id || "" }} onClose={() => setLinkDialog(null)} onSave={(values) => onAction("accounts", { action: "link", id: linkDialog.id, ...values })} />}
    {resetRequest && <FormDialog title={`Set temporary password · ${resetRequest.username}`} submitLabel="Approve reset" fields={[{ name: "new_password", label: "Temporary password", type: "password", required: true, minLength: 8, maxLength: 1024, help: "At least 8 characters. Share it with the user through a secure channel." }]} onClose={() => setResetRequest(null)} onSave={(values) => onAction("accounts", { action: "review-password-reset", id: resetRequest.id, status: "Approved", new_password: values.new_password })} />}
  </>;
}

function DocumentsPage({ data, onAction, user }) {
  const [selected, setSelected] = useState(null);
  const [createDialog, setCreateDialog] = useState(false);
  const isHr = user.role === "hr";
  const records = (data?.records || []).filter(
    (record) => user.role !== "hr" || record.request_type !== "Payslip"
  );
  const documentDescription = user.role === "viewer"
    ? "View your approved payslips, COEs, and other HR documents."
    : user.role === "hr"
      ? "Approved COEs, accomplishment reports, clearance, and pass-slip records."
      : user.role === "accounting"
        ? "View approved employee payslips."
        : "Approved payslips, COEs, accomplishment reports, clearance, and pass-slip records.";
  function details(row) {
    try { return JSON.parse(row.details); } catch { return {}; }
  }
  return <>
    <PageHeader title={user.role === "viewer" ? "My documents" : "Documents & records"}
      description={documentDescription}
      actions={isHr && <ActionButton kind="primary" onClick={() => setCreateDialog(true)}>+ Create document record</ActionButton>} />
    <section className="panel directory-panel">
      <div className="panel-heading directory-heading"><div><h2>{user.role === "accounting" ? "Approved payslips" : "Approved documents"}</h2><p>{user.role === "accounting" ? "Approved payslips remain available here for Accounting." : "Approved documents remain available here for employee and HR reference."}</p></div><span className="directory-count">{records.length} records</span></div>
      <Table columns={[
        ...(user.role !== "viewer" ? [{ key: "employee", label: "EMPLOYEE", render: (row) => employeeNameWithCode(row.employee, row.employee_id, row.employee_code) }] : []),
        { key: "request_type", label: "DOCUMENT" },
        ...(user.role !== "viewer" ? [{ key: "department", label: "DEPARTMENT" }] : []),
        { key: "submitted_at", label: "SUBMITTED" },
        { key: "reviewed_by", label: "APPROVED BY" },
      ]} rows={records} empty="No approved documents yet." renderActions={(row) => <ActionButton onClick={() => setSelected(row)}>Details</ActionButton>} />
    </section>
    {selected && <div className="dialog-scrim"><section className="work-dialog"><div className="dialog-heading"><div><span className="form-eyebrow">{selected.request_type}</span><h2>{selected.employee}</h2></div><button className="dialog-close" onClick={() => setSelected(null)} aria-label="Close">×</button></div>
      {selected.payslip ? <PayslipCard payslip={selected.payslip} /> : <dl className="request-details">{Object.entries(details(selected)).map(([key, value]) => <div key={key}><dt>{key.replaceAll("_", " ")}</dt><dd>{String(value)}</dd></div>)}</dl>}
      <div className="dialog-actions"><ActionButton onClick={() => setSelected(null)}>Close</ActionButton></div>
    </section></div>}
    {createDialog && <RequestFormDialog data={data} onAction={onAction} onClose={() => setCreateDialog(false)} documentMode />}
  </>;
}

function SettingsPage({ data, onAction, user }) {
  const [settings, setSettings] = useState({});
  const [employeeDetails, setEmployeeDetails] = useState(user.employee || {});
  const [settingsError, setSettingsError] = useState("");
  const [settingsSaving, setSettingsSaving] = useState(false);
  const [employeeError, setEmployeeError] = useState("");
  const [employeeSaving, setEmployeeSaving] = useState(false);
  const [profileImage, setProfileImage] = useState(user.profileImage || null);
  const [profileError, setProfileError] = useState("");
  const [profileSaving, setProfileSaving] = useState(false);
  const [passwordDialog, setPasswordDialog] = useState(false);
  const restoreInput = useRef(null);
  const [backupError, setBackupError] = useState("");
  const isAdmin = user.role === "admin";
  useEffect(() => {
    const next = data?.settings || {};
    setSettings({
      ...next,
      appearance_mode: document.documentElement.dataset.theme || "light",
    });
  }, [data]);
  useEffect(() => {
    setEmployeeDetails(user.employee || {});
  }, [user.employee]);
  useEffect(() => {
    setProfileImage(user.profileImage || null);
  }, [user.profileImage]);
  const appearance = settings.appearance_mode || "light";
  function chooseProfilePhoto(event) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!["image/png", "image/jpeg", "image/gif", "image/webp"].includes(file.type)) {
      setProfileError("Choose a PNG, JPEG, GIF, or WebP image.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setProfileError("Choose a profile photo smaller than 5 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== "string") {
        setProfileError("Could not read the selected profile photo.");
        return;
      }
      const image = new Image();
      image.onload = () => {
        setProfileImage(reader.result);
        setProfileError("");
      };
      image.onerror = () => setProfileError("The selected file is not a valid image.");
      image.src = reader.result;
    };
    reader.onerror = () => setProfileError("Could not read the selected profile photo.");
    reader.readAsDataURL(file);
  }
  async function saveProfile() {
    setProfileError("");
    setProfileSaving(true);
    try {
      await onAction("profile", { action: "save", profile_image: profileImage });
    } catch (error) {
      setProfileError(error.message);
    } finally {
      setProfileSaving(false);
    }
  }
  async function saveEmployeeDetails(event) {
    event.preventDefault();
    setEmployeeError("");
    setEmployeeSaving(true);
    try {
      await onAction("profile", { action: "save", employee: employeeDetails });
    } catch (error) {
      setEmployeeError(error.message);
    } finally {
      setEmployeeSaving(false);
    }
  }
  async function saveWorkplaceSettings(event) {
    event.preventDefault();
    setSettingsError("");
    setSettingsSaving(true);
    try {
      await onAction("settings", { action: "save", ...settings });
    } catch (error) {
      setSettingsError(error.message);
    } finally {
      setSettingsSaving(false);
    }
  }
  async function downloadBackup() {
    setBackupError("");
    try {
      const response = await fetch("/api/backup", { credentials: "same-origin" });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Could not back up the database.");
      }
      const blob = await response.blob();
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = response.headers.get("Content-Disposition")?.match(/filename="([^"]+)"/)?.[1] || "payroll-backup.sqlite3";
      link.click();
      URL.revokeObjectURL(link.href);
    } catch (error) {
      setBackupError(error.message);
    }
  }
  async function restoreBackup(file) {
    setBackupError("");
    if (file.size > 20 * 1024 * 1024) {
      setBackupError("Choose a backup smaller than 20 MB for web restore.");
      return;
    }
    if (!window.confirm("Restore replaces current payroll data. The system first saves a safety backup and signs you out. Continue?")) return;
    try {
      const bytes = new Uint8Array(await file.arrayBuffer());
      let binary = "";
      for (let offset = 0; offset < bytes.length; offset += 0x8000) {
        binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
      }
      await onAction("settings", { action: "restore", backup: btoa(binary) });
    } catch (error) {
      setBackupError(error.message);
    }
  }
  async function deleteDatabase() {
    setBackupError("");
    if (!window.confirm("Delete database will erase all employee, attendance, leave, payroll, request, and account data. A safety copy will be saved first. Continue?")) return;
    if (window.prompt('Type DELETE to permanently erase the current database and reset the system.') !== "DELETE") return;
    try {
      await onAction("settings", { action: "delete" });
    } catch (error) {
      setBackupError(error.message);
    }
  }
  return <>
    <PageHeader title="Settings" description="Organization preferences, company policies and account access." />
    <section className="panel settings-card">
      <div className="panel-heading"><div><h2>Your profile</h2><p>Manage your profile photo and account security.</p></div><ActionButton onClick={() => setPasswordDialog(true)}>Change password</ActionButton></div>
      <div className="profile-management">
        <div className="profile-picture">{profileImage ? <img src={profileImage} alt={`${user.username} profile`} /> : <span>{user.username.slice(0, 1).toUpperCase()}</span>}</div>
        <div className="profile-details"><strong>{user.username}</strong><span>{user.role}</span><div className="profile-actions">
          <label className="work-button profile-upload">Choose photo<input type="file" accept="image/png,image/jpeg,image/gif,image/webp" onChange={chooseProfilePhoto} /></label>
          <ActionButton onClick={() => { setProfileImage(null); setProfileError(""); }} disabled={!profileImage}>Remove photo</ActionButton>
          <ActionButton kind="primary" onClick={saveProfile} disabled={profileSaving || profileImage === (user.profileImage || null)}>{profileSaving ? "Saving…" : "Save profile"}</ActionButton>
        </div></div>
      </div>
      {profileError && <div className="form-error" role="alert">{profileError}</div>}
    </section>
    {user.role === "viewer" && user.employee && <section className="panel settings-card">
      <div className="panel-heading"><div><h2>Personal and emergency details</h2><p>Update inaccurate contact or identification details. HR and administrators see the saved changes immediately.</p></div></div>
      <form onSubmit={saveEmployeeDetails}>
        <div className="settings-fields employee-personal-fields">
          {[["first_name", "First name"], ["middle_name", "Middle name"], ["last_name", "Last name"], ["contact_number", "Contact number"], ["email", "Email"], ["address", "Address"], ["pagibig_number", "Pag-IBIG number"], ["sss_number", "SSS number"], ["tax_identification_number", "Tax identification number"], ["philhealth_number", "PhilHealth number"], ["emergency_contact_name", "Emergency contact name"], ["emergency_contact_number", "Emergency contact number"]].map(([name, label]) => <label className="form-field" key={name}><span>{label}</span>{name === "address" ? <textarea rows="3" value={employeeDetails[name] || ""} onChange={(event) => setEmployeeDetails({ ...employeeDetails, [name]: event.target.value })} /> : <input required={["first_name", "last_name"].includes(name)} type={name === "email" ? "email" : "text"} inputMode={["contact_number", "emergency_contact_number"].includes(name) ? "numeric" : undefined} value={employeeDetails[name] || ""} onChange={(event) => setEmployeeDetails({ ...employeeDetails, [name]: ["contact_number", "emergency_contact_number"].includes(name) ? filterContactNumber(event.target.value) : event.target.value })} />}</label>)}
        </div>
        {employeeError && <div className="form-error" role="alert">{employeeError}</div>}
        <div className="settings-actions"><button className="work-button primary" disabled={employeeSaving}>{employeeSaving ? "Saving personal details…" : "Save personal details"}</button></div>
      </form>
    </section>}
    <section className="panel settings-card workplace-card">
      <div className="panel-heading"><div><h2>Workplace information</h2><p>Organization details and useful information for your workday.</p></div></div>
      {isAdmin ? <form onSubmit={saveWorkplaceSettings}>
        <h3 className="settings-subheading">Organization details</h3>
        <div className="settings-fields">
          <label className="form-field"><span>Organization name</span><input maxLength={120} value={settings.organization_name || ""} onChange={(event) => setSettings({ ...settings, organization_name: event.target.value })} required /></label>
          <label className="form-field"><span>Workspace tagline</span><input maxLength={160} value={settings.organization_tagline || ""} onChange={(event) => setSettings({ ...settings, organization_tagline: event.target.value })} required /></label>
          <label className="form-field"><span>Office location</span><input maxLength={200} placeholder="Building, campus, or office" value={settings.office_location || ""} onChange={(event) => setSettings({ ...settings, office_location: event.target.value })} /></label>
          <label className="form-field"><span>HR contact</span><input maxLength={200} placeholder="Email address or phone number" value={settings.hr_contact || ""} onChange={(event) => setSettings({ ...settings, hr_contact: event.target.value })} /></label>
          <label className="form-field"><span>Payroll currency display</span><select value={settings.currency_symbol || "₱"} onChange={(event) => setSettings({ ...settings, currency_symbol: event.target.value })}>{["₱", "$", "€", "£", "¥"].map((symbol) => <option key={symbol}>{symbol}</option>)}</select><small>Display only. Stored values are not converted.</small></label>
        </div>
        <h3 className="settings-subheading">Work schedule reference</h3>
        <p className="settings-help">These are general workplace hours for reference. Employee-specific schedules and payroll calculations are managed separately.</p>
        <div className="settings-fields">
          <label className="form-field"><span>Working days</span><input maxLength={100} placeholder="Monday-Friday" value={settings.work_days || ""} onChange={(event) => setSettings({ ...settings, work_days: event.target.value })} /></label>
          <label className="form-field"><span>Break duration (minutes)</span><input type="number" min="0" max="180" step="1" value={settings.break_duration_minutes ?? "60"} onChange={(event) => setSettings({ ...settings, break_duration_minutes: event.target.value })} /></label>
          <label className="form-field"><span>Office start time</span><input type="time" value={settings.office_start_time || "09:00"} onChange={(event) => setSettings({ ...settings, office_start_time: event.target.value })} required /></label>
          <label className="form-field"><span>Office end time</span><input type="time" value={settings.office_end_time || "17:00"} onChange={(event) => setSettings({ ...settings, office_end_time: event.target.value })} required /></label>
        </div>
        <h3 className="settings-subheading">Workplace policies &amp; rules</h3>
        <label className="form-field policy-field"><span>Guidelines, attendance, leave, and workplace notes</span><textarea rows="6" maxLength={12000} value={settings.company_policies || ""} onChange={(event) => setSettings({ ...settings, company_policies: event.target.value })} placeholder="Add workplace expectations, leave guidance, attendance notes, or other information employees should know." /></label>
        {settingsError && <div className="form-error" role="alert">{settingsError}</div>}
        <div className="settings-actions"><button className="work-button primary" disabled={settingsSaving}>{settingsSaving ? "Saving workplace settings..." : "Save workplace settings"}</button></div>
      </form> : <>
        <div className="workplace-info-grid">
          <div><span>Organization</span><strong>{settings.organization_name || "LSPU PAYROLL SYSTEM"}</strong></div>
          <div><span>Office location</span><strong>{settings.office_location || "Not specified"}</strong></div>
          <div><span>HR contact</span><strong>{settings.hr_contact || "Contact your administrator"}</strong></div>
          <div><span>Working days</span><strong>{settings.work_days || "Monday-Friday"}</strong></div>
          <div><span>Office hours</span><strong>{settings.office_start_time || "09:00"} – {settings.office_end_time || "17:00"}</strong></div>
          <div><span>Break duration</span><strong>{settings.break_duration_minutes ?? "60"} minutes</strong></div>
        </div>
        <h3 className="settings-subheading">Workplace policies &amp; rules</h3>
        <p className="settings-help">For questions about these guidelines, contact HR.</p>
        <div className="policy-display">{settings.company_policies || "No workplace guidelines have been published yet. Please contact HR."}</div>
      </>}
    </section>
    <section className="panel settings-card"><div className="panel-heading"><div><h2>Appearance</h2><p>Choose the light or dark color theme for this workspace.</p></div><button className="work-button" onClick={async () => { const next = appearance === "light" ? "dark" : "light"; await onAction("settings", { action: "appearance", appearance_mode: next }); setSettings({ ...settings, appearance_mode: next }); document.documentElement.dataset.theme = next; }}>{appearance === "light" ? "Switch to dark mode" : "Switch to light mode"}</button></div></section>
    {isAdmin && <section className="panel settings-card danger-zone">
      <div className="danger-zone-divider" aria-hidden="true" />
      <div className="panel-heading">
        <div><span className="danger-zone-label">DANGER ZONE</span><h2>Database safety</h2><p>Backups contain sensitive employee and payroll information. Store them securely. Restoring replaces the current database.</p></div>
      </div>
      <div className="danger-zone-warning"><strong>Before restoring or deleting:</strong> A safety copy of the current database is saved before changes are made.</div>
      <div className="backup-actions">
        <input ref={restoreInput} className="database-restore-input" type="file" accept=".sqlite3,.db,.sqlite,application/vnd.sqlite3" onChange={(event) => { const file = event.target.files?.[0]; event.target.value = ""; if (file) restoreBackup(file); }} />
        <ActionButton onClick={() => restoreInput.current?.click()}>Restore database</ActionButton>
        <ActionButton onClick={downloadBackup}>Backup database</ActionButton>
        <ActionButton kind="danger" onClick={deleteDatabase}>Delete database</ActionButton>
      </div>
      {backupError && <div className="form-error" role="alert">{backupError}</div>}
    </section>}
    {passwordDialog && <FormDialog title="Change password" fields={[{ name: "current_password", label: "Current password", type: "password", required: true }, { name: "new_password", label: "New password", type: "password", required: true, help: "Use at least 8 characters." }]} onClose={() => setPasswordDialog(false)} onSave={(values) => onAction("accounts", { action: "change-password", ...values })} />}
  </>;
}

export default function WorkPages({ page, data, loading, onAction, onReload, onSearchEmployees, user, onNotify, accounts }) {
  if (loading && !data) return <div className="loading-state">Loading {page.toLowerCase()}…</div>;
  if (page === "Accounts") return <AccountsPage data={accounts || data} onAction={onAction} onReload={onReload} />;
  if (page === "Documents") return <DocumentsPage data={data} onAction={onAction} user={user} />;
  if (page === "Employees") return <EmployeesPage data={data} onAction={onAction} onReload={onReload} onSearchEmployees={onSearchEmployees} canEdit={user.role === "admin" || user.role === "hr"} canManageDepartments={user.role === "admin"} />;
  if (page === "Attendance") return <AttendancePage data={data} onAction={onAction} canEdit={user.role === "admin" || user.role === "hr"} />;
  if (page === "Leaves") return <LeavesPage data={data} onAction={onAction} canEdit={user.role === "admin"} />;
  if (page === "Payroll") return <PayrollPage data={data} onAction={onAction} canEdit={user.role === "admin" || user.role === "accounting"} />;
  if (page === "Reports") return <ReportsPage onNotify={onNotify} />;
  if (page === "Requests") return <RequestsPage data={data} onAction={onAction} user={user} />;
  if (page === "Settings") return <SettingsPage data={data} onAction={onAction} user={user} />;
  return <div className="loading-state">This section is not available.</div>;
}
