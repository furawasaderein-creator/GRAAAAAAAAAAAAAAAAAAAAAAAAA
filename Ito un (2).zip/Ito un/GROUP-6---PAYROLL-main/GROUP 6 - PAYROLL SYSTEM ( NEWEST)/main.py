from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="LSPU payroll application")
    parser.add_argument(
        "--desktop",
        action="store_true",
        help="launch the existing Tkinter application",
    )
    args = parser.parse_args()

    if args.desktop:
        import sqlite3
        import tkinter as tk
        from tkinter import messagebox

        from config import ensure_directories
        from payroll_app.application import PayrollApp

        ensure_directories()
        try:
            PayrollApp().mainloop()
        except (tk.TclError, sqlite3.Error, OSError) as exc:
            messagebox.showerror("Application Error", str(exc))
        return

    from server import main as run_web_app

    run_web_app()


if __name__ == "__main__":
    main()
